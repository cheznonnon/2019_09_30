// Nekomimi Nina RPG
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	n_gdi        gdi;
	n_bmp        bmp;
	n_posix_char msg[ 100 ];
	s32          x,y,sx,sy;

} n_window;




#define n_window_zero( p ) n_memory_zero( p, sizeof( n_window ) )

void
n_window_bitmap( n_window *p )
{

	n_bmp_free( &p->bmp );


	p->gdi.sx                = p->sx;
	p->gdi.sy                = p->sy;
	p->gdi.style             = N_GDI_SMOOTH;

	p->gdi.base_color_bg     = metric.color_window_1;
	p->gdi.base_color_fg     = metric.color_window_2;
	p->gdi.base_style        = N_GDI_BASE_VERTICAL;

	p->gdi.frame_style       = N_GDI_FRAME_RPG;
	p->gdi.frame_round       = metric.textsize / 3;

	p->gdi.text              = p->msg;
	p->gdi.text_font         = metric.font;
	p->gdi.text_size         = metric.textsize;
	p->gdi.text_color_main   = n_bmp_rgb( 255,255,255 );
	p->gdi.text_color_shadow = n_bmp_rgb(  10, 10, 10 );
	p->gdi.text_style        = N_GDI_TEXT_MONOSPACE | N_GDI_TEXT_SHADOW;
	p->gdi.text_fxsize1      = 1;

	n_gdi_bmp( &p->gdi, &p->bmp );


	return;
}

void
n_window_exit( n_window *p )
{

	n_bmp_free( &p->bmp );

	n_window_zero( p );


	return;
}

void
n_window_init( n_window *p, s32 x, s32 y, s32 sx, s32 sy )
{

	n_window_exit( p );


	p->x  =  x;
	p->y  =  y;
	p->sx = sx;
	p->sy = sy;


	return;
}

void
n_window_erase( n_window *p )
{

	if ( n_bmp_error( &p->bmp ) ) { return; }


	s32 tx = p->x;
	s32 ty = p->y;
	s32 sx = N_BMP_SX( &p->bmp );
	s32 sy = N_BMP_SY( &p->bmp );


	n_bmp_fastcopy( metric.bg, metric.canvas, tx,ty,sx,sy, tx,ty );


	return;
}

void
n_window_draw( n_window *p )
{

	if ( n_bmp_error( &p->bmp ) ) { return; }


	s32 tx = p->x;
	s32 ty = p->y;
	s32 sx = N_BMP_SX( &p->bmp );
	s32 sy = N_BMP_SY( &p->bmp );


	n_bmp_copy
	(
		&p->bmp, metric.canvas, 0,0,sx,sy, tx,ty,
		0.0, 0, 0,
		0//N_BMP_EDGE_ALL
	);


	return;
}




void
n_window_tip( n_window *p, const n_game_chara *c, u32 color )
{

	p->gdi.sx                 = 0;
	p->gdi.sy                 = 0;
	p->gdi.style              = N_GDI_SMOOTH;
	p->gdi.layout             = 0;
	p->gdi.align              = 0;

	p->gdi.base_color_bg      = metric.color_trans;
	p->gdi.base_color_fg      = metric.color_trans;
	p->gdi.base_style         = N_GDI_BASE_SOLID;

	p->gdi.frame_style        = N_GDI_FRAME_NOFRAME;

	p->gdi.text               = p->msg;
	p->gdi.text_font          = n_project_stdfont();
	p->gdi.text_size          = metric.textsize;
	p->gdi.text_color_main    = color;
	p->gdi.text_color_contour = n_bmp_rgb( 10,10,10 );
	p->gdi.text_style         = N_GDI_TEXT_CONTOUR;
	p->gdi.text_fxsize1       = 1;
	p->gdi.text_fxsize2       = 1;

	n_gdi_bmp( &p->gdi, &p->bmp );


	p->sx = N_BMP_SX( &p->bmp );
	p->sy = N_BMP_SY( &p->bmp );
	p->x  = c->x + n_game_centering( c->sx, p->sx );
	p->y  = ( c->y + c->sy ) - ( p->sy / 2 );


	return;
}


