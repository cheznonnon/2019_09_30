// Nekomimi Nina RPG
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#include "./__metric.c"
#include "./_window.c"




// [Mechanism] : Character Bitmap
//
//	X #0 Normal
//	X #1 Hit
//	X #2 Attack
//	X #3 Magic
//	X #4 Pinch
//	X #5 Exhausted
//
//	Y    frames for animation


#define N_PERSONNEL_FOCUS_OFF n_posix_literal( " " )
#ifdef UNICODE
#define N_PERSONNEL_FOCUS_ON  n_posix_literal( "\x2022" )
#else // #ifdef UNICODE
#define N_PERSONNEL_FOCUS_ON  n_posix_literal( ">" )
#endif // #ifdef UNICODE


#define N_COMMAND_ATTACK 0
#define N_COMMAND_MAGIC  1
#define N_COMMAND_HEAL   2
#define N_COMMAND_COUNT  3


typedef struct {

	n_posix_char focus[ 100 ];
	n_posix_char  name[ 100 ];
	n_game_sound sound;

} n_command;




typedef struct {

	n_posix_char name[ 16 ];

	n_game_chara chr;
	n_bmp        bmp;
	n_window     win;
	n_window     tip;
	u32          tip_color;
	n_command    cmd[ N_COMMAND_COUNT ];


	// [!] : all parameters use percentage (0-100)

	int hp;
	int mp;

	int physical;
	int magical;
	int weight;


	// [!] : for ActiveTimeBattle-like system

	int wait;

} n_personnel;



#define n_personnel_zero( p ) n_memory_zero( p, sizeof( n_personnel ) )

void
n_personnel_exit( n_personnel *p )
{

	n_bmp_free   ( &p->bmp );
	n_window_exit( &p->tip );


	n_window_exit( &p->win );


	int i = 0;
	while( 1 )
	{

		n_game_sound_exit( &p->cmd[ i ].sound );

		i++;
		if ( i >= N_COMMAND_COUNT ) { break; }
	}


	n_personnel_zero( p );


	return;
}

#define n_personnel_command_erase( p ) n_window_erase( &( p )->win )
#define n_personnel_command_draw(  p ) n_window_draw(  &( p )->win )

#define n_personnel_command_up(   p ) n_personnel_command_set( p, n_personnel_command_get( p ) - 1 )
#define n_personnel_command_down( p ) n_personnel_command_set( p, n_personnel_command_get( p ) + 1 )

int
n_personnel_command_get( n_personnel *p )
{

	int select = 0;


	int i = 0;
	while( 1 )
	{

		if ( n_string_is_same( N_PERSONNEL_FOCUS_ON, p->cmd[ i ].focus ) )
		{
			select = i;
			break;
		}

		i++;
		if ( i >= N_COMMAND_COUNT ) { break; }
	}


	return select;
}

void
n_personnel_command_set( n_personnel *p, int value )
{

	int select = ( N_COMMAND_COUNT + value ) % N_COMMAND_COUNT;


	int i = 0;
	while( 1 )
	{

		if ( i == select )
		{
			n_string_copy( N_PERSONNEL_FOCUS_ON,  p->cmd[ i ].focus );
		} else {
			n_string_copy( N_PERSONNEL_FOCUS_OFF, p->cmd[ i ].focus );
		}

		i++;
		if ( i >= N_COMMAND_COUNT ) { break; }
	}


	return;
}

void
n_personnel_command_bitmap( n_personnel *p )
{

	int i, cch;


	i = cch = 0;
	while( 1 )
	{

		cch += n_posix_sprintf_literal
		(
			&p->win.msg[ cch ],
			"%s%s%s",
			p->cmd[ i ].focus,
			p->cmd[ i ].name,
			N_STRING_CRLF
		);


		i++;
		if ( i >= N_COMMAND_COUNT ) { break; }
	}


	n_window_bitmap( &p->win );


	return;
}

void
n_personnel_neutral( n_personnel *p )
{

	// [!] : some parameters mean "don't draw"

	p->tip_color = n_bmp_trans;
	p->chr.srcx  = 0;
	p->chr.srcy  = 0;


	return;
}

#define n_personnel_init_literal( p, a, b, c, d, e, f, g, h ) \
	n_personnel_init( p, n_posix_literal( a ), b, c, d, \
		n_posix_literal( e ), n_posix_literal( f ), n_posix_literal( g ), n_posix_literal( h ) )

void
n_personnel_init
(
	      n_personnel  *p,
	const n_posix_char *name,
	      int           physical,
	      int           magical,
	      int           weight,
	const n_posix_char *rc_bitmap,
	const n_posix_char *rc_sound_0,
	const n_posix_char *rc_sound_1,
	const n_posix_char *rc_sound_2
)
{

	n_personnel_exit( p );


	// Personalizer

	n_string_copy( name, p->name );

	p->hp       = 100;
	p->mp       = 100;
	p->physical = physical;
	p->magical  = magical;
	p->weight   = weight;
	p->wait     = 0;


	// Command Window

	n_window_init( &p->win, metric.command_x, metric.command_y, metric.command_sx, metric.command_sy );

	n_string_copy_literal( "Attack", p->cmd[ 0 ].name );
	n_string_copy_literal( "Magic",  p->cmd[ 1 ].name );
	n_string_copy_literal( "Heal",   p->cmd[ 2 ].name );

	n_personnel_command_set( p, N_COMMAND_ATTACK );


	// Resources

	n_game_rc_load_bmp( &p->bmp, rc_bitmap );

	if ( metric.zoom == 1 )
	{

		u32 frame     = n_bmp_rgb( 0,200,255 );
		u32 trans_old; n_bmp_ptr_get_fast( &p->bmp, 0,0, &trans_old );
		u32 trans_new = metric.color_trans;


		n_bmp_transparent_onoff( &p->bmp, false );

		n_bmp_flush_replacer( &p->bmp, frame, trans_old );

		n_bmp_flush_replacer( &p->bmp, n_bmp_trans, trans_new );
		n_bmp_flush_antialias( &p->bmp, 1.0 );
		n_bmp_flush_replacer( &p->bmp,   trans_new, trans_old );

		n_bmp_scaler_lil( &p->bmp, 2 );

		n_bmp_transparent_onoff( &p->bmp, true );

	}


	n_game_chara_bmp( &p->chr, NULL, &p->bmp, NULL, 0 );
	n_game_chara_src( &p->chr, 0,0,metric.unit_bmp,metric.unit_bmp, 0,0 );

	p->chr.mx = p->chr.my = metric.unit_pad;


	n_game_sound_init( &p->cmd[ 0 ].sound, game.hwnd, rc_sound_0 ); n_wav_smoother( &p->cmd[ 0 ].sound.wav );
	n_game_sound_init( &p->cmd[ 1 ].sound, game.hwnd, rc_sound_1 ); n_wav_smoother( &p->cmd[ 1 ].sound.wav );
	n_game_sound_init( &p->cmd[ 2 ].sound, game.hwnd, rc_sound_2 ); n_wav_smoother( &p->cmd[ 2 ].sound.wav );


	n_personnel_neutral( p );


	return;
}

// internal
void
n_personnel_draw_effect( n_personnel *p )
{

	if ( p->tip_color == n_bmp_trans ) { return; }


	const s32 fx  = p->chr.srcx + p->chr.mx;
	const s32 fy  = p->chr.srcy + p->chr.my;
	const s32 fsx = p->chr.sx - ( p->chr.mx * 2 );
	const s32 fsy = p->chr.sy - ( p->chr.my * 2 );
	const s32 tx  = p->chr.x + p->chr.mx;
	const s32 ty  = p->chr.y + p->chr.my;


	n_bmp obj; n_bmp_zero( &obj ); n_bmp_1st_fast( &obj, fsx,fsy );

	n_bmp_fastcopy( &p->bmp, &obj, fx,fy,fsx,fsy, 0,0 );
	n_bmp_flush_mixer( &obj, p->tip_color, 0.5 );

	n_bmp_transcopy( &obj, metric.canvas, 0,0,fsx,fsy, tx,ty );

	n_bmp_free( &obj );


	return;
}

void
n_personnel_erase( n_personnel *p )
{

	{

		s32 sx = metric.unit_bmp - ( metric.unit_pad * 2 );
		s32 sy = metric.unit_bmp - ( metric.unit_pad * 2 );
		s32  x = metric.unit_pad + p->chr.x;
		s32  y = ( p->chr.y + p->chr.sy ) - metric.unit_pad;

		sy = (double) sy * 0.33;

		n_bmp_fastcopy( metric.bg, metric.canvas, x,y,sx,sy, x,y );

	}

	p->chr.bg   = metric.bg;
	p->chr.main = metric.canvas;
	n_game_chara_erase( &p->chr );

	n_window_erase( &p->tip );


	return;
}

void
n_personnel_draw( n_personnel *p, bool focus )
{

	if ( focus == false )
	{
		if ( p->hp ==  0 )
		{
			p->chr.srcx = metric.unit_bmp * 5;
		} else
		if ( p->hp <= 20 )
		{
			p->chr.srcx = metric.unit_bmp * 4;
		}
	}


	{

		s32 sx = metric.unit_bmp - ( metric.unit_pad * 2 );
		s32 sy = metric.unit_bmp - ( metric.unit_pad * 2 );

		n_bmp b; n_bmp_zero( &b ); n_bmp_1st_fast( &b, sx,sy );

		s32 src_x = p->chr.srcx + metric.unit_pad;
		s32 src_y = p->chr.srcy + metric.unit_pad;

		n_bmp_fastcopy( p->chr.chara, &b, src_x,src_y,sx,sy, 0,0 );
		n_bmp_flush_antialias( &b, 1.0 );

		n_bmp_flush_mirror( &b, N_BMP_MIRROR_UPSIDE_DOWN );
		n_bmp_resampler( &b, 1.0, 0.33 );

		s32 x = metric.unit_pad + p->chr.x;
		s32 y = ( p->chr.y + p->chr.sy ) - metric.unit_pad;

		n_bmp_blendcopy( &b, metric.canvas, 0,0,sx,sy, x,y, 0.5 );

		n_bmp_free( &b );

	}

	p->chr.main = metric.canvas;
	n_game_chara_draw( &p->chr );

	n_personnel_draw_effect( p );


	return;
}

void
n_personnel_sound( n_personnel *p )
{

	n_game_sound_loop( &p->cmd[ n_personnel_command_get( p ) ].sound );


	return;
}

void
n_personnel_tip_init( n_personnel *p, int value, u32 tip_color )
{

	p->tip_color = tip_color;

	if ( value == -1 )
	{
		n_posix_sprintf_literal( p->tip.msg, "Miss" );
	} else {
		n_posix_sprintf_literal( p->tip.msg, "%d", value );
	}

	n_window_tip( &p->tip, &p->chr, p->tip_color );


	return;
}

void
n_personnel_tip_exit( n_personnel *p )
{

	n_window_exit( &p->tip );


	return;
}

bool
n_personnel_attack( n_personnel *f, n_personnel *t )
{

	bool   is_done = false;
	double offense = f->physical;
	double defense = (double) t->physical / 100;
	double damage  = n_posix_max_double( 0, offense * ( 1.0 - defense ) );

//damage = 0;
	if ( ( f->hp > 0 )&&( damage != 0 ) )
	{

		is_done = true;

		t->hp = n_posix_max( 0, t->hp - damage );

		f->chr.srcx = metric.unit_bmp * 2;
		t->chr.srcx = metric.unit_bmp * 1;

		n_personnel_sound( f );
		n_personnel_tip_init( t, damage, metric.color_attack );

	} else {

		is_done = false;

		f->chr.srcx = metric.unit_bmp * 2;
		t->chr.srcx = metric.unit_bmp * 0;

		// [!] : no sound
		n_personnel_tip_init( t, -1, metric.color_attack );

	}


	return is_done;
}

bool
n_personnel_magic( n_personnel *f, n_personnel *t )
{

	bool   is_done = false;
	double offense = ( f->magical * 2 );
	double defense = (double) ( t->physical + t->magical ) / 100;
	double damage  = n_posix_max_double( 0, offense * ( 1.0 - defense ) );

//damage = 0;
	if ( ( f->mp > 0 )&&( damage != 0 ) )
	{

		is_done = true;

		t->hp = n_posix_max( 0, t->hp - damage );
		f->mp = n_posix_max( 0, f->mp - damage );

		f->chr.srcx = metric.unit_bmp * 3;
		t->chr.srcx = metric.unit_bmp * 1;

		n_personnel_sound( f );
		n_personnel_tip_init( t, damage, metric.color_magic );

	} else {

		is_done = false;

		f->chr.srcx = metric.unit_bmp * 1;
		t->chr.srcx = metric.unit_bmp * 0;

		// [!] : no sound
		n_personnel_tip_init( t, -1, metric.color_magic );

	}


	return is_done;
}

bool
n_personnel_heal( n_personnel *p )
{

	bool   is_done = false;
	double heal    = 0;


	if ( p->mp > 0 )
	{

		is_done = true;


		heal = p->magical;


		// Smart Healer

		if ( ( p->hp + heal ) > 100 ) { heal = 100 - p->hp; }


		p->hp = n_posix_min( 100, p->hp + heal );
		p->mp = n_posix_max(   0, p->mp - heal );

		p->chr.srcx = metric.unit_bmp * 3;

		n_personnel_sound( p );
		n_personnel_tip_init( p, heal, metric.color_magic );

	} else {

		is_done = false;

		p->chr.srcx = metric.unit_bmp * 3;

		// [!] : no sound
		n_personnel_tip_init( p, heal, metric.color_magic );

	}


	return is_done;
}

void
n_personnel_bulk_wait( n_personnel *p, int count )
{

	int i = 0;
	while( 1 )
	{

		// [!] : small value causes "always-same-value" problem

		p[ i ].wait += n_random_range( 1 + p[ i ].weight );


		i++;
		if ( i >= count ) { break; }
	}


	return;
}

void
n_personnel_bulk_wait_reset( n_personnel *p, int count )
{

	int i = 0;
	while( 1 )
	{

		p[ i ].wait = 0;


		i++;
		if ( i >= count ) { break; }
	}


	return;
}

int
n_personnel_bulk_wait_focus( n_personnel *p, int count )
{

	int focus = -1;
	int minim = SHRT_MAX;
	int i;


	// [Patch] : when HP is zero

	i = 0;
	while( 1 )
	{

		if ( p[ i ].hp == 0 ) { p[ i ].wait = SHRT_MAX; }

		i++;
		if ( i >= count ) { break; }
	}


	// [Patch] : all values are the same

	int same_value = p[ 0 ].wait;
	int same_count = 0;
	i = 0;
	while( 1 )
	{

		if ( same_value == p[ i ].wait ) { same_count++; }

		i++;
		if ( i >= count ) { break; }
	}

	if ( count == same_count ) { return focus; }


	i = 0;
	while( 1 )
	{

		if ( minim > p[ i ].wait )
		{
			minim = p[ i ].wait;
			focus = i;
		}


		i++;
		if ( i >= count ) { break; }
	}


	return focus;
}

