// Nonnon Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : #define is needed at first <commctrl.h> inclusion
//
//	#define WIN32_LEAN_AND_MEAN
//	#include <windows.h>
//	#define _WIN32_IE 0x0300
//	#include <commctrl.h>




// the base layer

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_popup.c"
#include "../nonnon/win32/win_systray.c"

#include "../nonnon/project/macro.c"



#define N_CALENDAR_SYSTRAY_ID 1




HWND
n_calendar_init( HWND hwnd_parent )
{

	INITCOMMONCONTROLSEX iccs = { sizeof( INITCOMMONCONTROLSEX ), ICC_DATE_CLASSES };

	HMODULE hmod;
	FARPROC func;

	HWND    hgui;


	// [!] : Win95a hasn't IE3

	hmod = LoadLibrary( n_posix_literal( "comctl32.dll" ) );
	if ( hmod == NULL ) { return NULL; }

	func = GetProcAddress( hmod, "InitCommonControlsEx" );
	if ( hmod == NULL ) { FreeLibrary( hmod ); return NULL; }

	func( &iccs );

	FreeLibrary( hmod );


	// [!] : hgui returns NULL on Win95b without IE4
	//
	//	#define _WIN32_IE 0x0400
	//	MCS_NOTODAYCIRCLE | MCS_NOTODAY

	hgui = CreateWindowEx
	(
		0,
		n_posix_literal( "SysMonthCal32" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		GetModuleHandle( NULL ),
		NULL
	);


	n_win_style_add( hgui, MCS_WEEKNUMBERS );


	return hgui;
}

void
n_calendar_resize( HWND hwnd, HWND hmonthcal )
{

	RECT r;     MonthCal_GetMinReqRect( hmonthcal, &r );
	s32  sx,sy; n_win_rect_expand_size( &r, NULL, NULL, &sx, &sy );

	n_win_popup_automove( hwnd, sx,sy );

	n_win_move_simple( hmonthcal, 0,0,sx,sy, false );


	return;
}

LRESULT CALLBACK
n_calendar_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const n_posix_char *appname    = n_posix_literal( "Nonnon Calendar" );
	const int           id_systray = N_CALENDAR_SYSTRAY_ID;

	const int           icon_index = 0;


	static NOTIFYICONDATA nid;
	static HWND           hmonthcal;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		// [!] : redirection is no effect

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hmonthcal );
		hmonthcal = n_calendar_init( hwnd );
		n_win_stdfont_init( &hmonthcal, 1 );

		if ( false == n_sysinfo_version_9x() )
		{
			n_win_systray_icon_change( &nid, NULL, icon_index );
		}

	break;


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );


		// Window

		hmonthcal = n_calendar_init( hwnd );


		// Style

		n_win_init_literal( hwnd, "", "", "" );

		n_win_popup_autostyle( hwnd, NULL,NULL );


		// Size

		n_win_stdfont_init( &hmonthcal, 1 );
		n_calendar_resize( hwnd, hmonthcal );


		// Init

		n_win_topmost( hwnd, true );


		// Display

		if ( sticky )
		{

			n_win_systray_init( &nid, hwnd, id_systray, N_STRING_EMPTY, appname, true );
			n_win_systray_icon_change( &nid, NULL, icon_index );

			ShowWindow( hwnd, SW_HIDE );

		} else {

			ShowWindow( hwnd, SW_NORMAL );

		}

	break;


	case WM_ACTIVATE :

		if ( sticky ) { break; }

		if ( wparam == WA_INACTIVE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case N_WIN_SYSTRAY_MESSAGE :

		if ( wparam != id_systray ) { break; }


		if ( lparam == WM_LBUTTONDOWN )
		{

			if ( IsWindowVisible( hwnd ) )
			{
				ShowWindow( hwnd, SW_HIDE );

			} else {

				n_calendar_resize( hwnd, hmonthcal );

				ShowWindow( hwnd, SW_NORMAL );
			}

		} else
		if ( lparam == WM_RBUTTONUP )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		} else
		if ( lparam == WM_LBUTTONDBLCLK )
		{
			//
		}

	break;


	case WM_CLOSE :

		n_win_stdfont_exit( &hmonthcal, 1 );

		n_win_systray_exit( &nid );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

