// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/filer.c"
#include "../nonnon/win32/win/commandline.c"

#include "../nonnon/project/macro.c"




int
main( void )
{

	// Phase 1 : set time stamp zero

	n_posix_char *timestamp = "Z:\\c\\@project\\timestamp.exe Z:\\c";

	n_win_execute( timestamp, SW_HIDE, true );


	// Phase 2 : copy Nonnon Win Unicode

	{

		n_posix_char *f = "Z:\\nonnon\\cheznonnon\\nonnon_win\\software\\nonnon_win_unicode";
		n_posix_char *t = "Z:\\freewares\\nonnon_win_unicode";

		if ( n_filer_is_locked( t ) )
		{
			n_project_dialog_info( NULL, n_project_string_error );
		} else {
			bool ret = n_filer_merge( f, t );
			if ( ret ) { n_project_dialog_info( NULL, n_project_string_error ); }
		}

	}

	// Phase 3 : copy Nonnon Win x64

	{

		n_posix_char *f = "Z:\\nonnon\\cheznonnon\\nonnon_win\\software\\nonnon_win_x64";
		n_posix_char *t = "Z:\\freewares\\nonnon_win_x64";

		if ( n_filer_is_locked( t ) )
		{
			n_project_dialog_info( NULL, n_project_string_error );
		} else {
			bool ret = n_filer_merge( f, t );
			if ( ret ) { n_project_dialog_info( NULL, n_project_string_error ); }
		}

	}


	return 0;
}

