// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_refresh_optimized_init( n_win_txtbox *p )
{

	p->prv_scr_x  = p->scroll_pxl_tabbed_x;
	p->prv_scr_y  = p->scroll_cch_tabbed_y;
	p->prv_sel_x  = p->select_cch_x;
	p->prv_sel_y  = p->select_cch_y;
	p->prv_txt_sx = p->txt.sx;
	p->prv_txt_sy = p->txt.sy;
	p->prv_sel_sx = p->select_cch_sx;
	p->prv_sel_sy = p->select_cch_sy;
	p->prv_drag   = p->shift_dragging;
	p->prv_caret  = p->caret_pxl_x;


	return;
}

void
n_win_txtbox_refresh_optimized_exit( n_win_txtbox *p, bool autoscroll_onoff )
{

	bool        moved = ( p->prv_sel_y != p->select_cch_y );
	bool     selected = ( ( p->prv_sel_sy != 1                      )||( p->select_cch_sy  != 1                      ) );
	bool     scrolled = ( ( p->prv_scr_x  != p->scroll_pxl_tabbed_x )||( p->prv_scr_y      != p->scroll_cch_tabbed_y ) );
	bool      updated = ( ( p->prv_txt_sx != p->txt.sx              )||( p->prv_txt_sy     != p->txt.sy              ) );
	bool autoscrolled = false;


	// [!] : keyboard input only
	//
	//	mouse input uses n_win_txtbox_drag()

	if ( autoscroll_onoff )
	{
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->shift_dragging );


		if ( p->is_font_monospace )
		{

			s32 stop_sx = p->select_cch_x;
			if ( ( p->shift_dragging == VK_RIGHT )&&( p->select_cch_sx > 0 ) ) { stop_sx += p->select_cch_sx; }

			s32 stop_sy = p->select_cch_y;
			if ( p->line_min_onoff ) { stop_sy += p->select_cch_sy - 1; }
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", stop_sy, p->select_cch_y );

			s32 fx = p->scroll_pxl_tabbed_x / p->font_pxl_sx;
			s32 tx = 0; n_win_txtbox_tabbedmetrics( p, stop_sy, -1,stop_sx,-1, NULL,NULL,&tx );
			s32 fy = p->scroll_cch_tabbed_y;
			s32 ty = p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy;


//n_win_txtbox_hwndprintf_literal( p, " N/A : %d ", tx );

			if ( stop_sy <  fy )
			{
//n_win_txtbox_hwndprintf_literal( p, " Top : %d ", ty );

				autoscrolled = true;
				n_win_txtbox_scroll( p, fx * p->font_pxl_sx, p->select_cch_y );

			} else
			if ( stop_sy >= ty )
			{
//n_win_txtbox_hwndprintf_literal( p, " Bottom : %d ", ty );

				autoscrolled = true;
				n_win_txtbox_scroll( p, fx * p->font_pxl_sx, p->select_cch_y - p->page_cch_tabbed_sy + 1 );

			}


			// [Needed] : for combination x and y

			fy = p->scroll_cch_tabbed_y;


			s32 usability = ( 3 * p->font_pxl_sx );

			if (
				( ( p->vk == VK_RIGHT )||( p->vk == VK_LBUTTON ) )
				&&
				( ( tx * p->font_pxl_sx ) >= ( p->scroll_pxl_tabbed_x + p->page_pxl_tabbed_sx - usability ) )
			)
			{
//n_win_txtbox_hwndprintf_literal( p, " Usability : %d ", tx );

				s32 p_scroll = p->scroll_pxl_tabbed_x;

				autoscrolled = true;
				n_win_txtbox_scroll( p, ( tx * p->font_pxl_sx ) - p->page_pxl_tabbed_sx + usability, fy );

				if ( p->vk == VK_LBUTTON )
				{
					POINT pt; GetCursorPos( &pt );
					SetCursorPos( pt.x - ( p->scroll_pxl_tabbed_x - p_scroll ), pt.y );
				}

			} else
			if ( ( tx * p->font_pxl_sx ) >= ( ( p->scroll_pxl_tabbed_x + p->page_pxl_tabbed_sx ) ) )
			{
//n_win_txtbox_hwndprintf_literal( p, " Right : %d ", tx );

				autoscrolled = true;
				n_win_txtbox_scroll( p, ( tx * p->font_pxl_sx ) - p->page_pxl_tabbed_sx, fy );

			} else
			if (
				( ( p->vk == VK_LEFT )||( p->vk == VK_LBUTTON ) )
				&&
				( fx > ( tx - 3 ) )
			)
			{
//n_win_txtbox_hwndprintf_literal( p, " Usability : %d ", tx );

				s32 p_scroll = p->scroll_pxl_tabbed_x;

				autoscrolled = true;
				n_win_txtbox_scroll( p, ( tx * p->font_pxl_sx ) - usability, fy );

				if ( p->vk == VK_LBUTTON )
				{
					POINT pt; GetCursorPos( &pt );
					SetCursorPos( pt.x + ( p_scroll - p->scroll_pxl_tabbed_x ), pt.y );
				}

			} else
			if ( fx > tx )
			{
//n_win_txtbox_hwndprintf_literal( p, " Left : %d ", tx );

				autoscrolled = true;
				n_win_txtbox_scroll( p, ( tx * p->font_pxl_sx ), fy );

			}

		} else {

			s32 scr_y = p->scroll_cch_tabbed_y;
			s32 sel_y = p->select_cch_y;
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, sel_y ) );

			// [Patch] : caret information will be invalid
			n_win_txtbox_draw( p );

			if ( p->prv_caret < p->caret_pxl_x )
			{
//n_win_txtbox_hwndprintf_literal( p, " Right : %d ", p->scroll_pxl_tabbed_x + p->caret_pxl_x );

				s32 target_x = p->canvas_real_pxl_sx + ( p->number_pxl_sx + p->number_pad_pxl_sx );
				if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) { target_x -= p->font_pxl_sx; }
				if ( p->caret_pxl_x > target_x )
				{
//n_win_txtbox_hwndprintf_literal( p, " Right : Scroll : %d : %d ", p->caret_pxl_x, p->canvas_real_pxl_sx );
					autoscrolled = true;
					n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x + ( p->caret_pxl_x - target_x ), scr_y );
				}

			} else
			if ( p->prv_sel_x > p->select_cch_x )
			{
//n_win_txtbox_hwndprintf_literal( p, " Left : %d ", p->caret_pxl_x );

//n_win_txtbox_scroll( p, 0, 0 );

				n_posix_char *str = n_win_txtbox_line_get_new( p, sel_y );
				str[ p->prv_sel_x    ] = N_STRING_CHAR_NUL;
				SIZE size_prv = n_win_txtbox_size_text( p, str );
				str[ p->select_cch_x ] = N_STRING_CHAR_NUL;
				SIZE size_cur = n_win_txtbox_size_text( p, str );
				n_string_free( str );
//n_win_txtbox_hwndprintf_literal( p, " Left : %d : %d ", p->caret_pxl_x, size_prv.cx - size_cur.cx );

				s32 target_x = p->caret_pxl_x - ( p->number_pxl_sx + p->number_pad_pxl_sx );
				if ( target_x < ( size_prv.cx - size_cur.cx ) )
				{
//n_win_txtbox_hwndprintf_literal( p, " Left : Scroll " );
					autoscrolled = true;
					n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x - ( size_prv.cx - size_cur.cx ), scr_y );
				}

			}

		}

	}


//n_win_txtbox_hwndprintf_literal( p, " Moved %d : Selected %d ", moved, selected );
	if ( moved )
	{
//n_win_txtbox_hwndprintf_literal( p, "Prv %d %d : Cur %d %d ", p->prv_sel_y, p->prv_sel_sy, p->select_cch_y, p->select_cch_sy );

		n_win_txtbox_caret_onoff( p );

		n_win_timer_init( p->hwnd, p->caret_timer, p->caret_msec );

		if ( false == ( selected | scrolled | updated | autoscrolled ) )
		{

			bool inner_prv;
			if ( ( p->prv_sel_y > p->scroll_cch_tabbed_y )&&( p->prv_sel_y < ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) ) )
			{
//n_win_txtbox_hwndprintf_literal( p, " Inner " );
				inner_prv =  true;
			} else {
//n_win_txtbox_hwndprintf_literal( p, " Outer " );
				inner_prv = false;
			}

			bool inner_cur;
			if ( ( p->select_cch_y > p->scroll_cch_tabbed_y )&&( p->select_cch_y < ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) ) )
			{
//n_win_txtbox_hwndprintf_literal( p, " Inner " );
				inner_cur =  true;
			} else {
//n_win_txtbox_hwndprintf_literal( p, " Outer " );
				inner_cur = false;
			}

			s32 f = n_posix_min_s32( p->prv_sel_y, p->select_cch_y );
			s32 t = n_posix_max_s32( 1, 1 + abs( p->prv_sel_y - p->select_cch_y ) );
			if ( ( inner_prv )&&( inner_cur ) )
			{
				//
			} else {
				if ( ( inner_prv == false )&&( inner_cur ) )
				{
					t = 1;
				} else {
					//
				}
			}

//n_win_txtbox_hwndprintf_literal( p, " Moved : %d %d : %d %d ", f, t, p->scroll_cch_tabbed_y, p->page_cch_tabbed_sy );

			n_win_txtbox_draw_partial( p, NULL, false, f, t );

			return;
		}

	}

	if ( selected )
	{

		if ( false == ( moved | scrolled | updated | autoscrolled ) )
		{

			s32 f = n_posix_min_s32( p->prv_sel_y , p->select_cch_y  );
			s32 t = n_posix_max_s32( p->prv_sel_sy, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " Selected %d %d ", f, t );

			n_win_txtbox_draw_partial( p, NULL, false, f, t );

			return;
		} else
		if ( false == ( scrolled | updated | autoscrolled ) )
		{

			n_win_txtbox_draw_partial( p, NULL, false, p->   prv_sel_y, p->   prv_sel_sy );
			n_win_txtbox_draw_partial( p, NULL, false, p->select_cch_y, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " Selected/Moved " );

			return;
		}

	}

	if ( moved | selected | scrolled | updated | autoscrolled )
	{
//n_win_txtbox_hwndprintf_literal( p, " All " );
		n_win_txtbox_refresh( p );
	} else {
//n_win_txtbox_hwndprintf_literal( p, " Partial " );
//n_win_txtbox_debug_count( p );
		n_win_txtbox_draw_selection( p );
	}


	return;
}


