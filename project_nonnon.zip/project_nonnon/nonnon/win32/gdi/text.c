// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#ifndef _H_NONNON_WIN32_GDI_TEXT
#define _H_NONNON_WIN32_GDI_TEXT




#include "../win/bitmap.c"
#include "../win/font.c"


#include "./effect.c"
#include "./font.c"




// internal
SIZE
n_gdi_text_precalc
(
	      n_gdi        *gdi,
	const n_posix_char *str,
	      size_t        cch
)
{


	SIZE size = { 0, 0 };


	if ( gdi == NULL ) { return size; }


	if ( cch == 0 ) { cch = n_posix_strlen( str ); }


	if ( gdi->pmr_onoff )
	{

		s32 sx,sy;
		n_game_pmr_calc( gdi->text_font, str, gdi->text_size, &sx, &sy, &gdi->text_cache_ratio, N_GAME_PMR_DRAW_L2R );

		size.cx = sx;
		size.cy = sy;

//n_posix_debug_literal( " %d %d ", sx, sy );

	} else
	if ( gdi->text_style & N_GDI_TEXT_MONOSPACE )
	{

		size.cx = gdi->text_cache_unit.cx * n_string_cb2cch( str, cch * sizeof( n_posix_char ) );
		size.cy = gdi->text_cache_unit.cy;

	} else {

		GetTextExtentPoint32( gdi->hdc_compat, str, cch, &size );

	}


	// [!] : italic needs more width

	if ( gdi->text_style & N_GDI_TEXT_ITALIC  )
	{
		size.cx += gdi->text_cache_unit.cx;
	}


	if ( gdi->text_style & N_GDI_TEXT_SMOOTH )
	{
		size.cx = ( size.cx / n_gdi_smoothness ) + 2;
		size.cy = ( size.cy / n_gdi_smoothness ) + 2;
	}


	gdi->effect_margin = 0;

	if ( ( n_gdi_fakebold_onoff )&&( gdi->text_style & N_GDI_TEXT_BOLD ) ) { gdi->effect_margin += 2; }

	if ( gdi->text_style & N_GDI_TEXT_CONTOUR ) { gdi->effect_margin += 2 * gdi->text_fxsize2; } else
	if ( gdi->text_style & N_GDI_TEXT_SINK    ) { gdi->effect_margin += 2 * gdi->text_fxsize2; }

	if ( gdi->text_style & N_GDI_TEXT_SHADOW  ) { gdi->effect_margin += 1 * gdi->text_fxsize1; }

	if ( gdi->text_style & N_GDI_TEXT_ELLIPSIS )
	{
		gdi->effect_margin += ( gdi->frame_size * 2 );
	}

	size.cx = size.cx + gdi->effect_margin;
	size.cy = size.cy + gdi->effect_margin;


	return size;
}

// internal
SIZE
n_gdi_text_precalc_unit( n_gdi *gdi, const n_txt *txt )
{

	SIZE size_ret = { 0, 0 };


	if ( gdi == NULL ) { return size_ret; }

	if ( n_txt_error( txt ) ) { return size_ret; }


	if ( gdi->text_style & N_GDI_TEXT_MONOSPACE )
	{

		// [!] : TEXTMETRIC.tmMaxCharWidth will be too large with ASCII code
		//
		//	"W" for GetTextExtentPoint32() is not almighty


		n_posix_char *s = txt->stream;
		if ( n_string_is_empty( s ) ) { s = N_STRING_SPACE; }

		size_t i = 0;
		while( 1 )
		{

			size_t cch = n_string_doublebyte_increment( s[ i ] );

			SIZE size;
			GetTextExtentPoint32( gdi->hdc_compat, &s[ i ], cch, &size );

			if ( size.cx > size_ret.cx ) { size_ret.cx = size.cx; }
			if ( size.cy > size_ret.cy ) { size_ret.cy = size.cy; }

			if ( ( cch == 2 )&&( s[ i + 1 ] == N_STRING_CHAR_NUL ) ) { break; }

			i += cch;
			if ( s[ i ] == N_STRING_CHAR_NUL ) { break; }
		}

	} else {

		size_ret = n_gdi_text_precalc( gdi, N_STRING_SPACE, 0 );

	}


	return size_ret;
}

// internal
void
n_gdi_text_draw_DrawText( const n_gdi *gdi, const n_posix_char *str, size_t length, s32 x, s32 y, s32 sx, s32 sy )
{

	const int dt = DT_NOPREFIX | DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );// | DT_NOCLIP;


	s32 dx  = 0;
	s32 dy  = 0;
	s32 dsx = 0;
	s32 dsy = 0;

	if ( ( n_gdi_fakebold_onoff )&&( gdi->text_style & N_GDI_TEXT_BOLD ) )
	{
		dsx = dsy = 2;
		if ( gdi->text_style & N_GDI_TEXT_SMOOTH ) { dx = dy = -1; }
	}

	s32 start_dx = dx;
	while( 1 )
	{

		RECT r = { x + dx, y + dy, x + sx + dx, y + sy + dy };
		DrawText( gdi->hdc_compat, str, length, &r, dt );

		dx++;
		if ( dx >= dsx )
		{
			dx = start_dx;
			dy++;
			if ( dy >= dsy ) { break; }
		}
	}

	return;
}

// internal
void
n_gdi_text_draw_line
(
	const n_gdi        *gdi,
	      n_bmp        *bmp,
	      n_posix_char *str,
	      size_t        length,
	      s32           sx,
	      s32           sy
)
{

	if ( gdi == NULL ) { return; }

	if ( n_bmp_error( bmp ) ) { return; }

	if ( n_string_is_empty( str ) ) { return; }


	// [!] : n_gdi_bmp_effect_text() will shrink automatically

	if ( gdi->text_style & N_GDI_TEXT_SMOOTH )
	{
		sx *= n_gdi_smoothness;
		sy *= n_gdi_smoothness;
	}


	n_bmp text; n_bmp_zero( &text ); n_bmp_1st_fast( &text, sx,sy );
	n_bmp_flush( &text, 0 );


	// [!]
	//
	//	CreateDIBitmap()     : use HDC returned by GetDC()
	//	GetDC()              : hbmp will be full-color bitmap
	//	CreateCompatibleDC() : hbmp will be monochrome bitmap
	//
	//	GDI functions        : use HDC returned by CreateCompatibleDC()
	//
	//	SelectObject()       : MSDN : unselect before GetDIBits()
	//
	// 	GetDIBits()          : different colors are returned when color depth is not 32bit


	if ( gdi->pmr_onoff )
	{

		s32 x = gdi->effect_margin / 2;
		s32 y = gdi->effect_margin / 2;

		n_game_pmr_draw( gdi->text_font, str, &text, x,y, gdi->text_cache_ratio, n_bmp_white, N_GAME_PMR_DRAW_L2R );

	} else {

		BITMAPINFO bi = { N_BMP_INFOH( &text ), { { 0,0,0,0 } } };

		HBITMAP hbmp   = CreateDIBitmap( gdi->hdc, &bi.bmiHeader, CBM_INIT, N_BMP_PTR( &text ), &bi, DIB_RGB_COLORS );
		HBITMAP p_hbmp = SelectObject( gdi->hdc_compat, hbmp );

		SetBkMode   ( gdi->hdc_compat, TRANSPARENT        );
		SetTextColor( gdi->hdc_compat, RGB( 255,255,255 ) );


		if ( length == 0 ) { length = n_posix_strlen( str ); }


		// [x] : ExtTextOut() is fastest but useless here
		//
		//	text will be rendered top-left always
		//	SetTextAlign( g.hdc_compat, TA_CENTER ); makes 0,0 as a center point
		//	manual handling is needed
		//
		//	ExtTextOut( gdi->hdc_compat, x,y, 0, &rect, str, length, NULL );
		//	TextOut( gdi->hdc_compat, x,y, str, length );

		if ( gdi->text_style & N_GDI_TEXT_MONOSPACE )
		{

			// [!] : forced monospace rendering
			//
			//	because n_win_font_logfont2hfont() is useless

			n_posix_char *s = str;
			if ( n_string_is_empty( s ) ) { s = N_STRING_SPACE; }

			s32 x = gdi->effect_margin;
			s32 y = gdi->effect_margin;

			size_t i = 0;
			while( 1 )
			{

				size_t cch = n_string_doublebyte_increment( s[ i ] );

				n_gdi_text_draw_DrawText( gdi, &s[ i ], cch, x,y,gdi->text_cache_unit.cx,sy );

				x += gdi->text_cache_unit.cx;
				if ( x >= sx ) { break; }

				i += cch;
				if ( i >= length ) { break; }
			}

		} else {

			n_gdi_text_draw_DrawText( gdi, str, length, 0,0,sx,sy );

		}


		SelectObject( gdi->hdc_compat, p_hbmp );
		GetDIBits( gdi->hdc_compat, hbmp, 0,N_BMP_SY( &text ), N_BMP_PTR( &text ), &bi, DIB_RGB_COLORS );
		n_win_bitmap_exit( hbmp );

	} 


	if ( N_BMP_ALPHA_CHANNEL_VISIBLE == 255 ) { n_bmp_alpha_visible( &text ); }


	n_gdi_bmp_effect_text( gdi, bmp, &text );


	n_bmp_free( &text );


	return;
}

void
n_gdi_text_cache_init( n_gdi *gdi, const n_txt *txt )
{

	if ( gdi == NULL ) { return; }

	if ( n_txt_error( txt ) ) { return; }


	if ( gdi->text_style & N_GDI_TEXT_SMOOTH ) { gdi->text_size *= n_gdi_smoothness; }

	gdi->text_cache_len   = n_memory_new_closed( txt->sy * sizeof( size_t ) );
	gdi->text_cache_size  = n_memory_new_closed( txt->sy * sizeof( SIZE   ) );
	gdi->text_cache_hfont = n_gdi_font( gdi );
	gdi->text_cache_pfont = SelectObject( gdi->hdc_compat, gdi->text_cache_hfont );
	gdi->text_cache_unit  = n_gdi_text_precalc_unit( gdi, txt );

	if ( gdi->text_style & N_GDI_TEXT_SMOOTH ) { gdi->text_size /= n_gdi_smoothness; }


	return;
}

void
n_gdi_text_cache_exit( n_gdi *gdi )
{

	n_memory_free_closed( gdi->text_cache_len  );
	n_memory_free_closed( gdi->text_cache_size );

	SelectObject        ( gdi->hdc_compat, gdi->text_cache_pfont );
	n_win_font_exit     ( gdi->text_cache_hfont );

	gdi->text_cache_len   = NULL;
	gdi->text_cache_size  = NULL;
	gdi->text_cache_pfont = gdi->text_cache_hfont = NULL;

	n_memory_zero( &gdi->text_cache_unit, sizeof( SIZE ) );


	return;
}

void
n_gdi_text_draw
(
	n_gdi *gdi,
	n_bmp *bmp,
	n_txt *txt,
	s32   *ret_sx,
	s32   *ret_sy
)
{

	// Phase 1 : initialization

	bool draw;

	if ( ( ret_sx != NULL )||( ret_sy != NULL ) )
	{
		draw = false;
	} else {
		draw = true;
	}


	if ( draw )
	{

		if (
			( gdi == NULL )
			||
			( n_txt_error( txt ) )
			||
			( n_bmp_error( bmp ) )
		)
		{

			n_gdi_text_cache_exit( gdi );

			return;
		}

	} else {

		if (
			( gdi == NULL )
			||
			( n_txt_error( txt ) )
		)
		{
			return;
		}

	}


	if ( ret_sx != NULL ) { (*ret_sx) = 0; }
	if ( ret_sy != NULL ) { (*ret_sy) = 0; }


	// Phase 2 : unit size calculation


	// [!] : 10% faster without strlen()

	const n_posix_char *ellipsis_dot     = n_posix_literal( "..." );
	const size_t        ellipsis_dot_cch = 3;//n_posix_strlen( ellipsis_dot );
	s32                 ellipsis_min     = 0;
	s32                 ellipsis_max     = 0;
	bool                ellipsis_onoff   = false;

	s32                 text_y           = gdi->text_y;
	s32                 text_sy          = 0;

	if ( draw )
	{

		//

	} else {

		n_gdi_text_cache_init( gdi, txt );


		if ( gdi->text_style & N_GDI_TEXT_ELLIPSIS )
		{

			s32 gdi_sx = gdi->sx - ( gdi->frame_size * 2 );

			if ( gdi->layout == N_GDI_LAYOUT_HORIZONTAL )
			{
				s32 pad = gdi->icon_sx / 2;
				ellipsis_min = ellipsis_max = n_posix_max_s32( 0, gdi_sx - gdi->icon_sx - pad );
			} else
			if ( gdi->layout == N_GDI_LAYOUT_VERTICAL )
			{
				ellipsis_min = ellipsis_max = n_posix_max_s32( 0, gdi_sx );
			}

			SIZE ellipsis_size = n_gdi_text_precalc( gdi, ellipsis_dot, 0 );
			ellipsis_min -= ellipsis_size.cx;

			if ( gdi_sx > 0 ) { ellipsis_onoff = true; }

		}

	}


	// Phase 2 : main

	n_posix_char *s;
	size_t        len;
	SIZE          size;


	size_t i = 0;
	while( 1 )
	{

		if ( draw )
		{

			s    = txt->line           [ i ];
			len  = gdi->text_cache_len [ i ];
			size = gdi->text_cache_size[ i ];

			n_gdi_text_draw_line( gdi, bmp, s, len, size.cx,size.cy );

			gdi->text_y += gdi->text_cache_size[ i ].cy;

		} else {

			len  = 0;
			s    = n_string_tab2space( txt->line[ i ], 8, &len );
			size = n_gdi_text_precalc( gdi, s, len );


			if ( ( gdi->text_style & N_GDI_TEXT_ELLIPSIS )&&( ellipsis_onoff )&&( size.cx > ellipsis_max ) )
			{

				size_t        ellipsis_len  = len + ellipsis_dot_cch;
				n_posix_char *ellipsis_str  = n_string_new_fast( ellipsis_len );
				n_posix_char *ellipsis_prv  = n_string_new_fast( ellipsis_len );
//n_string_copy( s, ellipsis_str );

				size_t cur_cch = 0;
				size_t prv_cch = 0;

				SIZE cur_size = { 0, 0 };
				SIZE prv_size = { 0, 0 };

				bool use_ellipsis_str = true;

				size_t cch = 0;
				while( 1 )
				{//break;

					cur_cch = n_posix_sprintf_literal( ellipsis_str, "%.*s%s", (int) cch, s, ellipsis_dot );
//n_posix_debug( ellipsis_str );

					cur_size = n_gdi_text_precalc( gdi, ellipsis_str, cur_cch );

					if ( cur_size.cx > ellipsis_max )
					{
						if ( cch != 0 )
						{
							use_ellipsis_str = false;
							cur_cch  = prv_cch;
							cur_size = prv_size;
						}
						break;
					}
					if ( ( cur_size.cx > ellipsis_min )&&( cur_size.cx < ellipsis_max ) )
					{
						break;
					} else {
						n_string_copy( ellipsis_str, ellipsis_prv );
						prv_cch  = cur_cch;
						prv_size = cur_size;
					}


					cch += n_string_doublebyte_increment( s[ cch ] );
					//if ( cch >= len ) { break; }
				}

				n_memory_free( s );

				if ( use_ellipsis_str )
				{
					s = ellipsis_str;
					n_memory_free( ellipsis_prv );
				} else {
					s = ellipsis_prv;
					n_memory_free( ellipsis_str );
				}

				len  = cur_cch;
				size = cur_size;

			}


			n_txt_mod_fast( txt, i, s );

			//n_memory_free( s );


			if ( ret_sx != NULL )
			{
				if ( (*ret_sx) < size.cx ) { (*ret_sx) = size.cx; }
			}

			if ( ret_sy != NULL ) { (*ret_sy) += size.cy; }


			gdi->text_cache_len [ i ] = len;
			gdi->text_cache_size[ i ] = size;

		}


		text_sy += gdi->text_cache_size[ i ].cy;


		i++;
		if ( i >= txt->sy ) { break; }
	}


	if ( draw )
	{
		n_gdi_text_cache_exit( gdi );
	}


	gdi->text_y  = text_y;
	gdi->text_sy = text_sy;


	return;
}


#endif // _H_NONNON_WIN32_GDI_TEXT

