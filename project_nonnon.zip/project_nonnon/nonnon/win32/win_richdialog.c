// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ Techniques : How to adjust padding ]
//
//	use a space or tab character
//
//
//	[ Techniques : How to make a separator ]
//
//	use N_GDI_TEXT_UNDERLINE or N_GDI_TEXT_STRIKEOUT for n_gdi.text_style


// [!] : gdi.icon, gdi.text : auto-free()
//
//	don't set these members by string literals
//	use n_string_carboncopy() for simple use




#ifndef _H_NONNON_WIN32_WIN_RICHDIALOG
#define _H_NONNON_WIN32_WIN_RICHDIALOG




#include "./gdi.c"
#include "./win.c"
#include "./win_iconbutton.c"




#define N_WIN_RICHDIALOG_MAX ( 32 )


typedef void (*n_win_richdialog_on_settingchange)( n_gdi* );


typedef struct {

	n_posix_char *title;
	n_gdi        *gdi;
	n_bmp        *bmp;
	size_t        gdi_used;
	bool          darkmode;

	s32           sx, sy;
	s32           padding;
	s32           header_sy;
	s32           margin_sy;
	s32           button_sy;

	HWND          hwnd;
	HWND          hbtn;

	bool          is_ok;

	u32           tick;

	n_win_richdialog_on_settingchange on_settingchange;

} n_win_richdialog;


static n_win_richdialog n_win_richdialog_instance;




n_gdi
n_win_richdialog_template( void )
{

	static n_posix_char text_font[ LF_FACESIZE ]; n_string_zero( text_font, LF_FACESIZE );
	                int text_size = 16;

	{

		NONCLIENTMETRICS ncm; ZeroMemory( &ncm, sizeof( NONCLIENTMETRICS ) );
		UINT              cb = sizeof( NONCLIENTMETRICS );

		ncm.cbSize = cb;
		SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );

		n_string_copy( ncm.lfMessageFont.lfFaceName, text_font );
		text_size = ncm.lfMessageFont.lfHeight;

	}


	static n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx              = 0;
	gdi.sy              = 0;
	gdi.style           = 0;//N_GDI_AUTOMARGIN;
	gdi.layout          = 0;
	gdi.align           = 0;

	gdi.base_color_bg   = n_bmp_rgb2pal( n_win_darkmode_systemcolor( COLOR_WINDOW ) );
	gdi.base_color_fg   = n_bmp_trans;
	gdi.base_style      = N_GDI_BASE_DEFAULT;

	gdi.frame_style     = N_GDI_FRAME_NOFRAME;

	gdi.icon            = NULL;//n_posix_literal( "" );
	gdi.icon_index      = 0;
	gdi.icon_style      = N_GDI_ICON_DEFAULT;

	gdi.text            = NULL;//n_posix_literal( "" );
	gdi.text_font       = text_font;
	gdi.text_size       = text_size;
	gdi.text_color_main = n_bmp_rgb2pal( n_win_darkmode_systemcolor( COLOR_WINDOWTEXT ) );
	gdi.text_style      = N_GDI_TEXT_DEFAULT;

	if ( n_sysinfo_version_vista_or_later() )
	{

		bool onoff = false;

		const UINT n_SPI_GETCLEARTYPE = 4168;
		SystemParametersInfo( n_SPI_GETCLEARTYPE, 0, &onoff, 0 );

		if ( onoff ) { gdi.text_style = N_GDI_TEXT_CLEAR; }

	}


	return gdi;
}

bool
n_win_richdialog_exit( n_win_richdialog *p )
{

	if ( p == NULL ) { return false; }


	bool ret = p->is_ok;


	size_t i = 0;
	while( 1 )
	{//break;

		n_bmp_free( &p->bmp[ i ] );

		n_string_free( p->gdi[ i ].icon );
		n_string_free( p->gdi[ i ].text );

		i++;
		if ( i >= p->gdi_used ) { break; }
	}

	n_memory_free( p->title );
	n_memory_free( p->gdi   );
	n_memory_free( p->bmp   );


	n_memory_zero( p, sizeof( n_win_richdialog ) );


	return ret;
}

void
n_win_richdialog_init( n_win_richdialog *p, size_t gdi_used, const n_posix_char *title )
{

	if ( p == NULL ) { return; }


	n_memory_zero( p, sizeof( n_win_richdialog ) );


	p->title    = n_string_carboncopy( title );
	p->gdi_used = n_posix_minmax( 1, N_WIN_RICHDIALOG_MAX, gdi_used );
	p->gdi      = n_memory_new( sizeof( n_gdi ) * p->gdi_used );
	p->bmp      = n_memory_new( sizeof( n_bmp ) * p->gdi_used );
	p->gdi[ 0 ] = n_win_richdialog_template();

	p->darkmode = true;

	n_bmp_zero( &p->bmp[ 0 ] );

	size_t i = 1;
	while( 1 )
	{

		n_gdi_alias( &p->gdi[ 0 ], &p->gdi[ i ] );
		n_bmp_alias( &p->bmp[ 0 ], &p->bmp[ i ] );

		i++;
		if ( i >= p->gdi_used ) { break; }
	}


	return;
}

void
n_win_richdialog_autosize( n_win_richdialog *p )
{
//return;

	if ( p == NULL ) { return; }


	n_win_stdsize( p->hwnd, &p->button_sy, NULL, NULL );

	p->margin_sy = p->button_sy * 2;
	p->padding   = p->button_sy / 4;


	s32 csx = ( p->padding * 2 );
	s32 csy = ( p->padding * 2 );

	size_t i = 0;
	while( 1 )
	{//break;

		n_gdi *g = &p->gdi[ i ];

		g->style = g->style | N_GDI_CALCONLY;
		g->sx    = 0;
		g->sy    = 0;

		n_gdi_bmp( g, NULL );

		g->style = g->style & ~N_GDI_CALCONLY;


		csx = n_posix_max_s32( csx, g->sx + ( p->padding * 2 ) );
		csy = csy + ( g->sy + p->padding );


		i++;
		if ( i >= p->gdi_used ) { break; }
	}

	p->header_sy = csy;


	p->sx = csx;
	p->sy = csy + p->margin_sy;


	return;
}

void
n_win_richdialog_bmp( n_win_richdialog *p )
{
//return;

	if ( p == NULL ) { return; }


	size_t i = 0;
	while( 1 )
	{//break;

		n_gdi *g = &p->gdi[ i ];
		n_bmp *b = &p->bmp[ i ];

		g->sx = 0;
		g->sy = 0;

		n_gdi_bmp( g, b );


		i++;
		if ( i >= p->gdi_used ) { break; }
	}


	return;
}

void
n_win_richdialog_draw( n_win_richdialog *p )
{
//return;

	if ( p == NULL ) { return; }


	// Init

	n_bmp canvas; n_bmp_zero( &canvas ); n_bmp_1st_fast( &canvas, p->sx,p->sy );


	// Background

	n_bmp_box( &canvas, 0,0,p->sx,p->header_sy, p->gdi[ 0 ].base_color_bg );


	// Draw

	s32    y = p->padding;
	size_t i = 0;
	while( 1 )
	{//break;

		n_gdi *g = &p->gdi[ i ];
		n_bmp *b = &p->bmp[ i ];


		s32 sx = N_BMP_SX( b );
		s32 sy = N_BMP_SY( b );
		s32  x = 0;

		if ( g->align == N_GDI_ALIGN_LEFT   ) { x = p->padding;                      } else
		if ( g->align == N_GDI_ALIGN_CENTER ) { x = ( p->sx - sx ) / 2;              } else
		if ( g->align == N_GDI_ALIGN_RIGHT  ) { x = p->sx - ( p->padding * 2 ) - sx; }

		n_bmp_fastcopy( b, &canvas, 0,0,sx,sy, x,y );

		y += sy + p->padding;


		i++;
		if ( i >= p->gdi_used ) { break; }
	}


	// Exit

	n_gdi_bitmap_draw( p->hwnd, &canvas, 0,0,p->sx,p->sy-p->margin_sy, 0,0 );


	{

		s32 sx,sy; n_win_size( p->hbtn, &sx, &sy );

		HDC hdc = n_gdi_doublebuffer_simple_init( p->hbtn, sx,sy );

		n_gdi_doublebuffer_simple_fill( GetSysColor( COLOR_BTNFACE ) );
		n_win_message_send( p->hbtn, WM_PRINTCLIENT, hdc, 0 );
//hdc = NULL;
		n_gdi_doublebuffer_simple_exit();

	}


	n_bmp_free( &canvas );


	return;
}

void
n_win_richdialog_resize( n_win_richdialog *p, bool is_first )
{

	if ( p == NULL ) { return; }


	int nws = N_WIN_SET_DEFAULT;
	s32 csx = -1;
	s32 csy = -1;

	if ( is_first )
	{
		nws = N_WIN_SET_CENTERING;
		csx = p->sx;
		csy = p->sy;
	}

	n_win w; n_win_set( p->hwnd, &w, csx,csy, nws );// | N_WIN_SET_CALCONLY );

	p->sx = w.csx;
	p->sy = w.csy;


	n_win_richdialog_draw( p );


	//n_win_set( p->hwnd, &w, csx,csy, nws );


	s32 btn_sy = p->button_sy;
	s32 btn_sx = (s32) ( (double) w.csx * 0.5 );
	s32 btn_x  = ( w.csx - btn_sx ) / 2;
	s32 btn_y  = p->header_sy + ( ( p->margin_sy - btn_sy ) / 2 );

	n_win_move_simple( p->hbtn, btn_x, btn_y, btn_sx, btn_sy, false );


	return;
}

#define n_win_richdialog_is_locked( p ) ( ( n_posix_tickcount() - ( p )->tick ) < 333 )

LRESULT CALLBACK
n_win_richdialog_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_richdialog *p = &n_win_richdialog_instance;


	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		n_win_timer_init( hwnd, timer_id, 500 );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		if ( p->darkmode ) { n_win_darkmode(); }

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, true );

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, p->hbtn );

		if ( p->on_settingchange != NULL )
		{

			p->gdi[ 0 ] = n_win_richdialog_template();

			size_t i = 1;
			while( 1 )
			{

				n_gdi_alias( &p->gdi[ 0 ], &p->gdi[ i ] );

				i++;
				if ( i >= p->gdi_used ) { break; }
			}

			p->on_settingchange( p->gdi );

			n_win_richdialog_bmp ( p );
			n_win_richdialog_draw( p );

		}

	break;


	case WM_CREATE :
//return -1;

		// Global

		//n_bmp_safemode = false;

		n_win_ime_disable( hwnd );

		p->hwnd = hwnd;


		// Window

		n_win_init_literal( hwnd, "", "", "" );

		n_win_gui_literal( hwnd, N_WIN_GUI_FLATBUTTON, "", &p->hbtn );

		n_win_text_set        ( p->hwnd, p->title );
		n_win_text_set_literal( p->hbtn, "OK"     );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, WS_POPUP | WS_CAPTION | WS_SYSMENU );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );

		n_win_style_add( p->hbtn, BS_DEFPUSHBUTTON );
		n_win_stdfont_init( &p->hbtn, 1 );

		n_win_iconbutton_init( hwnd, p->hbtn );


		// Size

		n_win_richdialog_autosize( p );
		n_win_richdialog_bmp( p );

		n_win_richdialog_resize( p, true );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		EnableWindow( n_win_hwnd_toplevel( hwnd ), false );


		// [!] : prevent accidental clicking

		p->tick = n_posix_tickcount();


	break;


	case WM_ERASEBKGND :

		// [x] : UxTheme : margin will be black

		//return true;

	break;

	case WM_PAINT :

		n_win_richdialog_draw( p );

	break;


	case WM_SIZE :

		n_win_richdialog_resize( p, false );

	break;


	case WM_COMMAND :

		if ( n_win_richdialog_is_locked( p ) ) { break; }

		if ( (HWND) lparam == p->hbtn )
		{
			p->is_ok = true;
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;

	case WM_KEYDOWN :

		if ( n_win_richdialog_is_locked( p ) ) { break; }

		if ( ( wparam == VK_SPACE )||( wparam == VK_RETURN ) )
		{
			n_win_iconbutton_status_change( p->hbtn, NULL, ODS_SELECTED );
		} else
		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}// else

	break;

	case WM_KEYUP :

		if ( n_win_richdialog_is_locked( p ) ) { break; }

		if ( ( wparam == VK_SPACE )||( wparam == VK_RETURN ) )
		{

			n_win_iconbutton_status_change( p->hbtn, NULL, ODS_SELECTED );

			p->is_ok = true;
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		}// else

	break;


	case WM_CLOSE :

		EnableWindow( n_win_hwnd_toplevel( hwnd ), true );


		n_win_stdfont_exit( &p->hbtn, 1 );

		n_win_iconbutton_exit( hwnd, p->hbtn );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, p->hbtn );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

bool
n_win_richdialog_go( n_win_richdialog *p, HWND hwnd_parent )
{

	if ( p == NULL ) { return false; }

	if ( hwnd_parent == NULL ) { return false; }


	n_win_gui( hwnd_parent, N_WIN_GUI_WINDOW, n_win_richdialog_wndproc, &p->hwnd );


	// [!] : don't use GetMessage() : a closed process will remain in background

	while( 1 )
	{

		MSG msg; n_win_message_peek( &msg );

		TranslateMessage( &msg );
		DispatchMessage ( &msg );

		if ( false == IsWindow( p->hwnd ) ) { break; }

		n_posix_sleep( 1 );

	}


//n_win_hwndprintf_literal( hwnd_parent, "%d", p->is_ok );


	return n_win_richdialog_exit( p );
}




#endif // _H_NONNON_WIN32_WIN_RICHDIALOG


/*


#include "../project/macro.c"


LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :

		// Global

		n_project_darkmode();
		//n_win_darkmode_onoff = true;


		// Window

		n_win_init_literal( hwnd, "Nonnon Rich Dialog", "", "" );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		// Size

		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_LBUTTONDOWN :
	{

		if ( IsWindow( n_win_richdialog_instance.hwnd ) ) { break; }


		n_win_richdialog_init( &n_win_richdialog_instance, 2, n_project_string_info );


		n_gdi *gdi = n_win_richdialog_instance.gdi;

		gdi[ 0 ].icon        = n_posix_literal( "../project/neko.multi.ico" );
		gdi[ 0 ].text        = n_posix_literal( "Nonnon" );
		gdi[ 0 ].text_style  = gdi[ 0 ].text_style | N_GDI_TEXT_BOLD;

		gdi[ 1 ].text        = n_posix_literal( "Copyright (c) nonnon All Rights Reserved." );


		n_win_richdialog_go( &n_win_richdialog_instance, hwnd );

	}
	break;


	case WM_CLOSE :

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


*/

