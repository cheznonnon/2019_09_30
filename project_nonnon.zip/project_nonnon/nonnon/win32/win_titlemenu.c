// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Limitaion]
//
//	one main window only
//	use as template




#ifndef _H_NONNON_WIN32_WIN_TITLEMENU
#define _H_NONNON_WIN32_WIN_TITLEMENU




#include "./win_menu.c"




typedef struct {

	HHOOK hhook;
	HWND  hwnd;
	HMENU hmenu;
	bool  onoff;

} n_win_titlemenu;




static n_win_titlemenu *n_win_titlemenu_target = NULL;




LRESULT CALLBACK
n_win_titlemenu_MouseProc( int nCode, WPARAM wParam, LPARAM lParam )
{

	n_win_titlemenu *p = n_win_titlemenu_target;

	if ( ( p != NULL )&&( nCode == HC_ACTION ) )
	{

		MOUSEHOOKSTRUCT *mh = (void*) lParam;
//n_win_hwndprintf_literal( mh->hwnd, " %d %d ", wParam, mh->wHitTestCode );

		if ( wParam == WM_NCRBUTTONDOWN ) // 164
		{
			if ( ( p->hwnd == mh->hwnd )&&( p->onoff ) )
			{
				n_win_menu_popup_show( p->hmenu, p->hwnd );
			}

			return true;
		} else
		if ( wParam == WM_NCLBUTTONDOWN )
		{
			if ( mh->wHitTestCode == HTSYSMENU ) // 3
			{
				//return true;
			}
		}

	}

	return CallNextHookEx( p->hhook, nCode, wParam, lParam );
}

void
n_win_titlemenu_init( n_win_titlemenu *p, HWND hwnd )
{

	p->hhook = SetWindowsHookEx( WH_MOUSE, n_win_titlemenu_MouseProc, GetModuleHandle( NULL ), GetWindowThreadProcessId( hwnd, NULL ) );
	p->hwnd  = hwnd;
	p->hmenu = n_win_menu_popup_hmenu_init();
	p->onoff = true;


	n_win_titlemenu_target = p;


	return;
}

void
n_win_titlemenu_exit( n_win_titlemenu *p )
{

	UnhookWindowsHookEx( p->hhook );

	n_win_menu_popup_hmenu_exit( p->hmenu );


	p->hhook = NULL;
	p->hwnd  = NULL;
	p->hmenu = NULL;


	n_win_titlemenu_target = NULL;


	return;
}


#endif // _H_NONNON_WIN32_WIN_TITLEMENU


