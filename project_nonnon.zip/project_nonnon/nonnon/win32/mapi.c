// Nonnon Mail Manager
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_MAPI
#define _H_NONNON_WIN32_MAPI




#include "../neutral/string.c"




#include <mapi.h>




#define n_mapi_send_literal( address, title, text ) n_mapi_send( n_posix_literal( address ), n_posix_literal( title ), n_posix_literal( text ) )

bool
n_mapi_send( n_posix_char *address, n_posix_char *title, n_posix_char *text )
{

	// [Mechanism] : "address" is always needed


	HMODULE hmod = LoadLibrary( n_posix_literal( "mapi32.dll" ) );
	if ( hmod == NULL )
	{
//n_posix_debug_literal( " LoadLibrary() " );
		return 0;
	}


	bool is_unicode = true;


	// [!] : Win8 or later : MAPISendMailW()

	FARPROC n_MAPISendMail = GetProcAddress( hmod, "MAPISendMailW" );

	// [x] : Win7 or earlier : MAPISendMailHelper() is not found
	//
	//	fallback to ANSI version is needed

	if ( n_MAPISendMail == NULL )
	{
		n_MAPISendMail = GetProcAddress( hmod, "MAPISendMailHelper" );
	}

	if ( n_MAPISendMail == NULL )
	{
		is_unicode = false;
		n_MAPISendMail = GetProcAddress( hmod, "MAPISendMail" );
	}


	if ( n_MAPISendMail == NULL )
	{
//n_posix_debug_literal( " GetProcAddress() " );
		FreeLibrary( hmod );

		return 0;
	}


	typedef struct {

		ULONG ulReserved;
		ULONG ulRecipClass;
		PWSTR lpszName;
		PWSTR lpszAddress;
		ULONG ulEIDSize;
		PVOID lpEntryID;

	} MapiRecipDescW, *lpMapiRecipDescW;

	typedef struct {

		ULONG ulReserved;
		ULONG flFlags;
		ULONG nPosition;
		PWSTR lpszPathName;
		PWSTR lpszFileName;
		PVOID lpFileType;

	} MapiFileDescW, *lpMapiFileDescW;

	typedef struct {

		ULONG            ulReserved;
		PWSTR            lpszSubject;
		PWSTR            lpszNoteText;
		PWSTR            lpszMessageType;
		PWSTR            lpszDateReceived;
		PWSTR            lpszConversationID;
		FLAGS            flFlags;
		lpMapiRecipDescW lpOriginator;
		ULONG            nRecipCount;
		lpMapiRecipDescW lpRecips;
		ULONG            nFileCount;
		lpMapiFileDescW  lpFiles;

	} MapiMessageW, *lpMapiMessageW;


	int ret = SUCCESS_SUCCESS;

	if ( is_unicode )
	{

		MapiMessageW   msg; ZeroMemory( &msg, sizeof( MapiMessageW   ) );
		MapiRecipDescW dsc; ZeroMemory( &dsc, sizeof( MapiRecipDescW ) );

#ifndef UNICODE

		wchar_t *str_address = n_posix_ansi2unicode( address );
		wchar_t *str_title   = n_posix_ansi2unicode( title   );
		wchar_t *str_text    = n_posix_ansi2unicode( text    );

#else  // #ifndef UNICODE

		wchar_t *str_address = address;
		wchar_t *str_title   = title;
		wchar_t *str_text    = text;

#endif // #ifndef UNICODE

		dsc.ulRecipClass = MAPI_TO;
		dsc.lpszName     = str_address;

		msg.lpszSubject  = str_title;
		msg.lpszNoteText = str_text;
		msg.nRecipCount  = 1;
		msg.lpRecips     = &dsc;

		ret = n_MAPISendMail( 0, NULL, &msg, MAPI_LOGON_UI | MAPI_DIALOG, 0 );

#ifndef UNICODE

		n_memory_free( str_address );
		n_memory_free( str_title   );
		n_memory_free( str_text    );

#endif // #ifndef UNICODE

	} else {

		MapiMessage    msg; ZeroMemory( &msg, sizeof( MapiMessage    ) );
		MapiRecipDesc  dsc; ZeroMemory( &dsc, sizeof( MapiRecipDesc  ) );

#ifdef UNICODE

		char *str_address = n_posix_unicode2ansi( address );
		char *str_title   = n_posix_unicode2ansi( title   );
		char *str_text    = n_posix_unicode2ansi( text    );

#else  // #ifdef UNICODE

		char *str_address = address;
		char *str_title   = title;
		char *str_text    = text;

#endif // #ifdef UNICODE

		dsc.ulRecipClass = MAPI_TO;
		dsc.lpszName     = str_address;

		msg.lpszSubject  = str_title;
		msg.lpszNoteText = str_text;
		msg.nRecipCount  = 1;
		msg.lpRecips     = &dsc;

		ret = n_MAPISendMail( 0, NULL, &msg, MAPI_LOGON_UI | MAPI_DIALOG, 0 );

#ifdef UNICODE

		n_memory_free( str_address );
		n_memory_free( str_title   );
		n_memory_free( str_text    );

#endif // #ifdef UNICODE

	}


	FreeLibrary( hmod );


	return ( ret != SUCCESS_SUCCESS );
}


#endif // _H_NONNON_WIN32_MAPI


