// nlayer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_COLORPICKER
#define _H_NONNON_WIN32_WIN_COLORPICKER




#include "./win/_debug.c"
#include "./win/input.c"
#include "./win/message.c"
#include "./win/style.c"
#include "./win_scroller.c"





// [!] : for easy to read/replace

#define nwclr_refresh      n_win_colorpicker_refresh
#define nwclr_move         n_win_colorpicker_move
#define nwclr_enable       n_win_colorpicker_enable
#define nwclr_proc         n_win_colorpicker_proc




// [!] : internal

#define H_COLOR  c->hgui[ 0 ]
#define GUI_MAX           1


#define H_SCR_A  ( &c->hscr[ 0 ] )
#define H_SCR_R  ( &c->hscr[ 1 ] )
#define H_SCR_G  ( &c->hscr[ 2 ] )
#define H_SCR_B  ( &c->hscr[ 3 ] )
#define SCR_MAX              4



typedef struct {

	// [!] : for incompatibility between RGB() and n_bmp_rgb()

	u8             a,r,g,b;


	// internal

	HWND           hgui[ GUI_MAX ];
	n_win_scroller hscr[ SCR_MAX ];

	bool           grayscale_onoff;

} n_win_colorpicker;




#define n_win_colorpicker_zero( p ) n_memory_zero( p, sizeof( n_win_colorpicker ) )

void
n_win_colorpicker_on_settingchange( n_win_colorpicker *c )
{

	n_win_scroller_on_settingchange( H_SCR_A );
	n_win_scroller_on_settingchange( H_SCR_R );
	n_win_scroller_on_settingchange( H_SCR_G );
	n_win_scroller_on_settingchange( H_SCR_B );

	return;
}

void
n_win_colorpicker_scroller_value_set( n_win_colorpicker *c, n_win_scroller *s, int v )
{

	n_win_hwndprintf_literal( s->value, "%3d", v );

	return;
}

void
n_win_colorpicker_scroller_refresh( n_win_colorpicker *c, n_win_scroller *s, int v )
{

	//n_win_message_send( GetParent( s->canvas ), WM_COMMAND, v, n_win_scroller_scroll_hwnd( s ) );

	n_win_colorpicker_scroller_value_set( c, s, v );

	s->scrollbar.unit_pos = v;

	n_win_scrollbar_draw_always( &s->scrollbar, true );


	return;
}

void
n_win_colorpicker_refresh( n_win_colorpicker *c, int a, int r, int g, int b )
{

	if ( c == NULL ) { return; }


	if ( false == IsWindowEnabled( H_COLOR ) ) { return; }


	c->a = a;
	c->r = r;
	c->g = g;
	c->b = b;

	n_win_colorpicker_scroller_refresh( c, H_SCR_A, a );
	n_win_colorpicker_scroller_refresh( c, H_SCR_R, r );
	n_win_colorpicker_scroller_refresh( c, H_SCR_G, g );
	n_win_colorpicker_scroller_refresh( c, H_SCR_B, b );

	c->grayscale_onoff = false;

	n_win_refresh( H_COLOR, true );


	return;
}

void
n_win_colorpicker_init( n_win_colorpicker *c, HWND hwnd )
{

	if ( c == NULL ) { return; }


	n_win_scroller_zero( H_SCR_A );
	n_win_scroller_zero( H_SCR_R );
	n_win_scroller_zero( H_SCR_G );
	n_win_scroller_zero( H_SCR_B );


	// Window

	n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS,  "", &H_COLOR );

	n_win_scroller_init_literal( H_SCR_A, hwnd, "A" );
	n_win_scroller_init_literal( H_SCR_R, hwnd, "R" );
	n_win_scroller_init_literal( H_SCR_G, hwnd, "G" );
	n_win_scroller_init_literal( H_SCR_B, hwnd, "B" );


	// Style

	n_win_style_add( H_COLOR, SS_NOTIFY );


	// Scrollbars

	n_win_scroller_scroll_parameter( H_SCR_A, 1, 10, 255, c->a, true );
	n_win_scroller_scroll_parameter( H_SCR_R, 1, 10, 255, c->r, true );
	n_win_scroller_scroll_parameter( H_SCR_G, 1, 10, 255, c->g, true );
	n_win_scroller_scroll_parameter( H_SCR_B, 1, 10, 255, c->b, true );

	n_win_colorpicker_refresh( c, c->a, c->r, c->g, c->b );


	return;
}

void
n_win_colorpicker_exit( n_win_colorpicker *c )
{

	if ( c == NULL ) { return; }


	// Window

	DestroyWindow( H_COLOR );

	n_win_scroller_exit( H_SCR_A );
	n_win_scroller_exit( H_SCR_R );
	n_win_scroller_exit( H_SCR_G );
	n_win_scroller_exit( H_SCR_B );


	return;
}

void
n_win_colorpicker_move( n_win_colorpicker *c, s32 x, s32 y, s32 sx, s32 sy, bool redraw )
{

	if ( c == NULL ) { return; }


	// Size

	s32 ty = sy / 4;

	nwscr_move( H_SCR_A, x,y+(ty*0),sx,ty, redraw );
	nwscr_move( H_SCR_R, x,y+(ty*1),sx,ty, redraw );
	nwscr_move( H_SCR_G, x,y+(ty*2),sx,ty, redraw );
	nwscr_move( H_SCR_B, x,y+(ty*3),sx,ty, redraw );


	// [!] : hack here

	s32 m; n_win_stdsize( NULL, NULL, NULL, &m );

	s32 unit = sx / 10;

	s32 clr_x  = x + ( m * 2 );
	s32 clr_y  = y + ( m * 1 );
	s32 clr_sx = ( unit * 1 ) - ( m * 2 );
	s32 clr_sy =   sy         - ( m * 2 );

	n_win_move_simple( H_SCR_A->label, x+unit+m, H_SCR_A->text__y, clr_sx,H_SCR_A->text_sy, redraw );
	n_win_move_simple( H_SCR_R->label, x+unit+m, H_SCR_R->text__y, clr_sx,H_SCR_R->text_sy, redraw );
	n_win_move_simple( H_SCR_G->label, x+unit+m, H_SCR_G->text__y, clr_sx,H_SCR_G->text_sy, redraw );
	n_win_move_simple( H_SCR_B->label, x+unit+m, H_SCR_B->text__y, clr_sx,H_SCR_B->text_sy, redraw );
	n_win_move_simple( H_COLOR       ,    clr_x,            clr_y, clr_sx,          clr_sy, redraw );


	// [Needed]

	n_win_colorpicker_refresh( c, c->a, c->r, c->g, c->b );


	return;
}

void
n_win_colorpicker_enable( n_win_colorpicker *c, bool enable )
{

	EnableWindow( H_COLOR, enable );
	nwscr_enable( H_SCR_A, enable );
	nwscr_enable( H_SCR_R, enable );
	nwscr_enable( H_SCR_G, enable );
	nwscr_enable( H_SCR_B, enable );


	return;
}

void
n_win_colorpicker_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_colorpicker *c )
{

	if ( c == NULL ) { return; }


	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;

		if ( di == NULL ) { break; }
		if ( H_COLOR != di->hwndItem ) { break; }


		HDC  hdc = di->hDC;
		RECT r   = di->rcItem;


		n_win_box( NULL, hdc, &r, RGB( c->r, c->g, c->b ) );


		if ( false == IsWindowEnabled( H_COLOR ) ) { break; }

		if ( c->grayscale_onoff )
		{
			DrawEdge( hdc, &r, BDR_SUNKEN,      BF_RECT );
		} else {
			DrawEdge( hdc, &r, BDR_SUNKENOUTER, BF_RECT | BF_MONO );
		}

	}
	break;

	case WM_COMMAND :
	{

		static bool lock = false;


		bool sync = false;


		if ( (HWND) lparam == H_COLOR )
		{

			if ( STN_CLICKED == HIWORD( wparam ) )
			{

				if ( c->grayscale_onoff )
				{
					c->grayscale_onoff = false;
				} else {
					c->grayscale_onoff = true;
				}

				n_win_refresh( H_COLOR, true );

			}

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( H_SCR_A ) )
		{

			int prv = c->a;

			c->a = wparam;

			if ( c->a != prv ) { sync = true; }

			n_win_colorpicker_scroller_value_set( c, H_SCR_A, c->a );

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( H_SCR_R ) )
		{

			int prv = c->r;

			c->r = wparam;

			if ( c->r != prv ) { sync = true; }


			n_win_colorpicker_scroller_value_set( c, H_SCR_R, c->r );


			if ( lock ) { break; }

			if ( ( c->grayscale_onoff )||( n_win_is_input( VK_CONTROL ) ) )
			{

				lock = true;

				c->g = c->b = c->r;

				n_win_colorpicker_scroller_refresh( c, H_SCR_G, c->r );
				n_win_colorpicker_scroller_refresh( c, H_SCR_B, c->r );

				sync = true;

				lock = false;

			}

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( H_SCR_G ) )
		{

			int prv = c->g;

			c->g = wparam;

			if ( c->g != prv ) { sync = true; }


			n_win_colorpicker_scroller_value_set( c, H_SCR_G, c->g );


			if ( lock ) { break; }

			if ( ( c->grayscale_onoff )||( n_win_is_input( VK_CONTROL ) ) )
			{

				lock = true;

				c->r = c->b = c->g;

				n_win_colorpicker_scroller_refresh( c, H_SCR_R, c->g );
				n_win_colorpicker_scroller_refresh( c, H_SCR_B, c->g );

				sync = true;

				lock = false;

			}

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( H_SCR_B ) )
		{

			int prv = c->b;

			c->b = wparam;

			if ( c->b != prv ) { sync = true; }


			n_win_colorpicker_scroller_value_set( c, H_SCR_B, c->b );


			if ( lock ) { break; }

			if ( ( c->grayscale_onoff )||( n_win_is_input( VK_CONTROL ) ) )
			{

				lock = true;

				c->r = c->g = c->b;

				n_win_colorpicker_scroller_refresh( c, H_SCR_R, c->b );
				n_win_colorpicker_scroller_refresh( c, H_SCR_G, c->b );

				sync = true;

				lock = false;

			}

		}

		if ( sync ) { n_win_refresh( H_COLOR, true ); }

	}
	break;


	} // switch


	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_A );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_R );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_G );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_B );


	return;
}


#undef GUI_MAX
#undef H_COLOR

#undef SCR_MAX
#undef H_SCR_A
#undef H_SCR_R
#undef H_SCR_G
#undef H_SCR_B


#endif // _H_NONNON_WIN32_WIN_COLORPICKER


/*


#include "./win.c"


#include "../project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_colorpicker cp;


	switch( msg ) {


	case WM_CREATE :

		// Global

		n_project_darkmode();
		//n_win_darkmode_onoff = true;


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );

		n_win_colorpicker_zero( &cp );
		n_win_colorpicker_init( &cp, hwnd );

		n_win_colorpicker_refresh( &cp, 0, 0, 200, 255 );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		// Size

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );

		n_win_colorpicker_move( &cp, 0,0,200,200, true );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		n_win_colorpicker_exit( &cp );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_colorpicker_proc( hwnd, msg, wparam, lparam, &cp );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


*/


