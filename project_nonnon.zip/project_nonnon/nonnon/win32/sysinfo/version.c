// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : don't include win32/registry.c in this file




#ifndef _H_NONNON_WIN32_SYSINFO_VERSION
#define _H_NONNON_WIN32_SYSINFO_VERSION




#include "../../neutral/posix.c"




OSVERSIONINFO
n_sysinfo_version_realversion_internal( void )
{

	// [!] : ignore troublesome compatibility layer


	DWORD         cb = sizeof( OSVERSIONINFO );
	OSVERSIONINFO osver; ZeroMemory( &osver, cb );
	osver.dwOSVersionInfoSize = cb;

	GetVersionEx( &osver );


	HMODULE hmod = LoadLibrary( n_posix_literal( "ntdll.dll" ) );
	FARPROC func = GetProcAddress( hmod, "RtlGetNtVersionNumbers" );

	if ( func )
	{

		func( &osver.dwMajorVersion, &osver.dwMinorVersion, &osver.dwBuildNumber );
		osver.dwBuildNumber &= 0x0000FFFF;

//n_posix_debug_literal( " %d %d %d ", osver.dwMajorVersion, osver.dwMinorVersion, osver.dwBuildNumber );
	}


	FreeLibrary( hmod );


	return osver;
}

OSVERSIONINFO
n_sysinfo_version_realversion( void )
{

	static bool          is_first = true;
	static OSVERSIONINFO osver = { 0,0,0,0,0,n_posix_literal( "" ) };

	if ( is_first )
	{
		is_first = false;
		osver = n_sysinfo_version_realversion_internal();
	}


	return osver;
}

bool
n_sysinfo_realversion_7_or_later( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_realversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		(
			( ( osver.dwMajorVersion == 6 )&&( osver.dwMinorVersion >= 1 ) )
			||
			( osver.dwMajorVersion >= 7 )
	)
	)
	{
		return true;
	}


	return false;
}




OSVERSIONINFO
n_sysinfo_version_getversion_internal( void )
{

	DWORD         cb = sizeof( OSVERSIONINFO );
	OSVERSIONINFO osver; ZeroMemory( &osver, cb );
	osver.dwOSVersionInfoSize = cb;

	GetVersionEx( &osver );


	return osver;
}

OSVERSIONINFO
n_sysinfo_version_getversion( void )
{

	static bool          is_first = true;
	static OSVERSIONINFO osver = { 0,0,0,0,0,n_posix_literal( "" ) };

	if ( is_first )
	{
		is_first = false;
		osver = n_sysinfo_version_getversion_internal();
	}


	return osver;
}

bool
n_sysinfo_version_9x( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if ( osver.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS )
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_95( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS )
		&&
		( ( osver.dwMajorVersion == 4 )&&( osver.dwMinorVersion == 0 ) )
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_98( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS )
		&&
		( ( osver.dwMajorVersion ==  4 )&&( osver.dwMinorVersion == 10 ) )
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_me( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS )
		&&
		( ( osver.dwMajorVersion ==  4 )&&( osver.dwMinorVersion == 90 ) )
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_nt( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if ( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_nt4( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		( osver.dwMajorVersion == 4 )
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_2000( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		( ( osver.dwMajorVersion == 5 )&&( osver.dwMinorVersion == 0 ) )
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_xp( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		( ( osver.dwMajorVersion == 5 )&&( osver.dwMinorVersion != 0 ) )
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_vista( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		( ( osver.dwMajorVersion == 6 )&&( osver.dwMinorVersion == 0 ) )
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_7( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		( ( osver.dwMajorVersion == 6 )&&( osver.dwMinorVersion == 1 ) )
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_2000_or_later( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		( osver.dwMajorVersion >= 5 )
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_xp_or_later( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		(
			( ( osver.dwMajorVersion == 5 )&&( osver.dwMinorVersion >= 1 ) )
			||
			( osver.dwMajorVersion >= 6 )
		)
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_vista_or_later( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		( osver.dwMajorVersion >= 6 )
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_7_or_later( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		(
			( ( osver.dwMajorVersion == 6 )&&( osver.dwMinorVersion >= 1 ) )
			||
			( osver.dwMajorVersion >= 7 )
	)
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_8_or_later( void )
{

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		(
			( ( osver.dwMajorVersion == 6 )&&( osver.dwMinorVersion >= 2 ) )
			||
			( osver.dwMajorVersion >= 7 )
		)
	)
	{
		return true;
	}


	return false;
}

bool
n_sysinfo_version_10_or_later( void )
{

	// [Needed] : written this in manifest file
	//
	//	<supportedOS Id="{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}"/>

	OSVERSIONINFO osver = n_sysinfo_version_getversion();


	// [!] : version will be 10.0

	if (
		( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
		&&
		(
			( ( osver.dwMajorVersion == 6 )&&( osver.dwMinorVersion >= 4 ) )
			||
			( osver.dwMajorVersion >= 7 )
		)
	)
	{
		return true;
	}


	return false;
}


#endif // _H_NONNON_WIN32_SYSINFO_VERSION




/*


int
main( void )
{

	if ( n_sysinfo_version_9x() ) { MessageBoxA( NULL, "9x", "DEBUG", 0 ); }
	if ( n_sysinfo_version_nt() ) { MessageBoxA( NULL, "NT", "DEBUG", 0 ); }

	if ( n_sysinfo_version_95() ) { MessageBoxA( NULL, "95", "DEBUG", 0 ); }
	if ( n_sysinfo_version_98() ) { MessageBoxA( NULL, "98", "DEBUG", 0 ); }
	if ( n_sysinfo_version_me() ) { MessageBoxA( NULL, "Me", "DEBUG", 0 ); }

	if ( n_sysinfo_version_2000()  ) { MessageBoxA( NULL, "2000",  "DEBUG", 0 ); }
	if ( n_sysinfo_version_xp()    ) { MessageBoxA( NULL, "XP",    "DEBUG", 0 ); }
	if ( n_sysinfo_version_vista() ) { MessageBoxA( NULL, "Vista", "DEBUG", 0 ); }


	return 0;
}


*/

