// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html



// [!] : n_bmp_*_channel()
//
//	use "int" for performance
//	10% faster than "u8"


// [!] : multithread : don't use "static" cache : data will break




#ifndef _H_NONNON_NEUTRAL_BMP_COLOR
#define _H_NONNON_NEUTRAL_BMP_COLOR




#include <math.h>




#include "../bmp.c"
#include "../random.c"


#include "./_error.c"
#include "./_transparent.c"




//const double n_bmp_coeff_channel = 1.0 / 255.0;

#define n_bmp_coeff_channel ( 0.003921568627451 )




#define n_bmp_clamp_channel( v ) n_posix_minmax( 0, 255, (int) v )
/*
inline int
n_bmp_clamp_channel( int v )
{

	// [!] : 0.5% slower than above macro

	if ( v < 0 ) { v = 0; } else if ( v > 255 ) { v = 255; }


	return v;
}
*/

#define n_bmp_simplify_channel( v, n ) ( 255 - ( ( 255 - ( v ) ) / n * n ) )

u32
n_bmp_grayscale_pixel( u32 color )
{

	// [!] : alpha is reserved

	int a = n_bmp_a( color );
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );

	r = g = b = ( r + g + b ) / 3;


	return n_bmp_argb( a,r,g,b );
}

double
n_bmp_blend_alpha2ratio( int alpha )
{

	// [!] : don't use inline : cache will be independent (maybe)

	if ( n_bmp_is_multithread )
	{

		double a = (double) alpha * n_bmp_coeff_channel;

#ifdef N_BMP_ALPHA_MODE_STANDARD
		double p_ret = ( N_BMP_ALPHA_RATIO_VISIBLE - a );
#else  // #ifdef N_BMP_ALPHA_MODE_STANDARD
		double p_ret = a;
#endif // #ifdef N_BMP_ALPHA_MODE_STANDARD


		return p_ret;

	} else {

		static int    p_alpha = 0;
		static double p_ret   = 0;

		if ( p_alpha == alpha ) { return p_ret; }

		double a = (double) alpha * n_bmp_coeff_channel;

		p_alpha = alpha;

#ifdef N_BMP_ALPHA_MODE_STANDARD
		p_ret = ( N_BMP_ALPHA_RATIO_VISIBLE - a );
#else  // #ifdef N_BMP_ALPHA_MODE_STANDARD
		p_ret = a;
#endif // #ifdef N_BMP_ALPHA_MODE_STANDARD


		return p_ret;

	}

}

inline int
n_bmp_blend_channel( int f, int t, double blend )
{

	// [!] : inline : bloat but faster


	// [!] : shortcut

	if ( f == t ) { return t; }

	if ( blend <= 0 ) { return f; }
	if ( blend >= 1 ) { return t; }


	// [!] : 20% faster than comment-out'ed code
	//
	//	cast to int is very important
	//
	//	logic :  5%
	//	cast  : 15%

	// [!] : don't use calculus in min()/max() when macro

	double d = ( f - t ) * blend;

	if ( f > t )
	{
		return f - (int) n_posix_max_double(  1.0, d );
	} else {
		return f - (int) n_posix_min_double( -1.0, d );
	}

/*
	double d = ( t - f ) * blend;

	if ( ( d > -1.0 )&&( d < 1.0 ) )
	{
		if ( f < t ) { d = 1; } else { d = -1; }
	}

	return f + d;
*/
}

u32
n_bmp_blend_pixel( u32 f, u32 t, double blend )
{

	// [!] : 10% faster

	if ( f == t ) { return f; }

	if ( blend <= 0.0 ) { return f; }
	if ( blend >= 1.0 ) { return t; }


	// [!] : cache : 5% faster but multithread unsafe

	if ( n_bmp_is_multithread )
	{

		return n_bmp_argb
		(
			n_bmp_blend_channel( n_bmp_a( f ), n_bmp_a( t ), blend ),
			n_bmp_blend_channel( n_bmp_r( f ), n_bmp_r( t ), blend ),
			n_bmp_blend_channel( n_bmp_g( f ), n_bmp_g( t ), blend ),
			n_bmp_blend_channel( n_bmp_b( f ), n_bmp_b( t ), blend )
		);

	}


	static u32 p_color = 0;

	{

		static u32    p_f = 0;
		static u32    p_t = 0;
		static double p_d = 0;

		if ( ( p_f == f )&&( p_t == t )&&( p_d == blend ) ) { return p_color; }

		p_f = f;
		p_t = t;
		p_d = blend;

	}


	int f_a = n_bmp_a( f );
	int f_r = n_bmp_r( f );
	int f_g = n_bmp_g( f );
	int f_b = n_bmp_b( f );
	int t_a = n_bmp_a( t );
	int t_r = n_bmp_r( t );
	int t_g = n_bmp_g( t );
	int t_b = n_bmp_b( t );


	int a,r,g,b;


	a = n_bmp_blend_channel( f_a, t_a, blend );

	if ( ( f_r == f_a )&&( t_r == t_a ) )
	{
		r = a;
	} else
	{
		r = n_bmp_blend_channel( f_r, t_r, blend );
	}

	if ( ( f_g == f_a )&&( t_g == t_a ) )
	{
		g = a;
	} else
	if ( ( f_g == f_r )&&( t_g == t_r ) )
	{
		g = r;
	} else
	{
		g = n_bmp_blend_channel( f_g, t_g, blend );
	}

	if ( ( f_b == f_a )&&( t_b == t_a ) )
	{
		b = a;
	} else
	if ( ( f_b == f_r )&&( t_b == t_r ) )
	{
		b = r;
	} else
	if ( ( f_b == f_g )&&( t_b == t_g ) )
	{
		b = g;
	} else
	{
		b = n_bmp_blend_channel( f_b, t_b, blend );
	}


	p_color = n_bmp_argb( a,r,g,b );


	return p_color;
}

#define N_BMP_GRADIENT_RECTANGLE  0
#define N_BMP_GRADIENT_CIRCLE     1

inline int
n_bmp_gradient_channel( int f, int t, double x, double y, double r, int mode )
{

	// [Mechanism]
	//
	//	from : thick : center
	//	  to : thin  : outside
	//
	//	x==0 :   vertical gradient
	//	y==0 : horizontal gradient


	// [!] : double is slower than s32/int
	//
	//	but you cannot make an image with 3000px or more


	if ( r <= 0 ) { return f; }
	if ( f == t ) { return t; }


	// [Patch] : smaller circle will be drawn

	r++;


	// [!] : "int" is 40% faster than "double"


	// [!] : pow( n, 2 ) is too much heavy

	x *= x;
	y *= y;
	r *= r;


	double p;

	if ( mode == N_BMP_GRADIENT_CIRCLE )
	{
		p = x + y;
	} else {
		if ( x > y ) { p = x; } else { p = y; }
	}

	if ( p > r ) { p = r; }


	// [!] : this is 2x slower than below code
	//return n_bmp_blend_channel( f, t, (double) p / r );


	double line_1 = f * ( r - p );
	double line_2 = t * (     p );


	return (int) ( ( line_1 + line_2 ) / r );
}

u32
n_bmp_gradient_pixel( u32 f,u32 t, s32 x,s32 y,s32 r, int mode )
{

	return n_bmp_argb
	(
		n_bmp_gradient_channel( n_bmp_a( f ), n_bmp_a( t ), x,y,r, mode ),
		n_bmp_gradient_channel( n_bmp_r( f ), n_bmp_r( t ), x,y,r, mode ),
		n_bmp_gradient_channel( n_bmp_g( f ), n_bmp_g( t ), x,y,r, mode ),
		n_bmp_gradient_channel( n_bmp_b( f ), n_bmp_b( t ), x,y,r, mode )
	);
}
/*
int
n_bmp_contrast_channel( int ch, int param )
{

	if ( ch < (       param ) ) { return   0; } else
	if ( ch > ( 255 - param ) ) { return 255; }


	double d0 = ch - param;
	double d1 = (double) 256 / ( (double) 256 - ( param * 2 ) );


	return d0 * d1;
}

u32
n_bmp_contrast_pixel( u32 color, int param )
{

	int a =                         n_bmp_a( color )         ;
	int r = n_bmp_contrast_channel( n_bmp_r( color ), param );
	int g = n_bmp_contrast_channel( n_bmp_g( color ), param );
	int b = n_bmp_contrast_channel( n_bmp_b( color ), param );

	return n_bmp_argb( a,r,g,b );
}
*/
u32
n_bmp_contrast_pixel( u32 color, int param )
{

	int a = n_bmp_a( color );
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );


	double factor = ( 259.0 * ( param + 255.0 ) ) / ( 255.0 * ( 259.0 - param ) );

	r = n_posix_minmax( 0, 255, (int) ( ( factor * ( r - 128 ) ) + 128 ) );
	g = n_posix_minmax( 0, 255, (int) ( ( factor * ( g - 128 ) ) + 128 ) );
	b = n_posix_minmax( 0, 255, (int) ( ( factor * ( b - 128 ) ) + 128 ) );


	return n_bmp_argb( a,r,g,b );
}

#define n_bmp_alpha_visible_pixel(   color ) n_bmp_alpha_replace_pixel( color, N_BMP_ALPHA_CHANNEL_VISIBLE   )
#define n_bmp_alpha_invisible_pixel( color ) n_bmp_alpha_replace_pixel( color, N_BMP_ALPHA_CHANNEL_INVISIBLE )

u32
n_bmp_alpha_replace_pixel( u32 color, int alpha )
{

	int a = alpha;
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );

	return n_bmp_argb( a,r,g,b );
}

u32
n_bmp_div_pixel( int a, int r, int g, int b, int n )
{

	if ( n <= 1 ) { return n_bmp_argb( a,r,g,b ); }


	// [!] : division is too slow : 20% faster

	if ( a != 0 ) { a /= n; }

	if ( r == g )
	{

		if ( r == b )
		{
			if ( r != 0 ) { r = g = b = r / n; }
		} else {
			if ( r != 0 ) { r = g = r / n; }
			if ( b != 0 ) { b /= n; }
		}

	} else
	if ( r == b )
	{

		if ( r != 0 ) { r = b = r / n; }
		if ( g != 0 ) { g /= n; }

	} else {

		if ( r != 0 ) { r /= n; }
		if ( g != 0 ) { g /= n; }
		if ( b != 0 ) { b /= n; }

	}


	return n_bmp_argb( a,r,g,b );
}

u32
n_bmp_antialias_pixel( const n_bmp *bmp, s32 x, s32 y, double blend )
{

	// [!] : n_bmp_blend_pixel() is heavy


	u32 center;

	if (
		( n_bmp_ptr_get( bmp, x,y, &center ) )
		||
		( n_bmp_is_trans( bmp, center ) )
	)
	{
		return n_bmp_trans;
	}


	// [!] : nothing to do

	if ( blend <= 0.0 ) { return center; }


	int avr = 1;

	int a = n_bmp_a( center );
	int r = n_bmp_r( center );
	int g = n_bmp_g( center );
	int b = n_bmp_b( center );


	int i = 0;
	while( 1 )
	{

		s32 tx = x;
		s32 ty = y;

		if ( i == 0 ) { ty--; } else
		if ( i == 1 ) { ty++; } else
		if ( i == 2 ) { tx--; } else
		if ( i == 3 ) { tx++; }


		u32 color;

		if (
			( false == n_bmp_ptr_get( bmp, tx,ty, &color ) )
			&&
			( false == n_bmp_is_trans( bmp, color ) )
		)
		{

			avr++;

			a += n_bmp_a( color );
			r += n_bmp_r( color );
			g += n_bmp_g( color );
			b += n_bmp_b( color );

		}


		i++;
		if ( i >= 4 ) { break; }
	}


	return n_bmp_blend_pixel( center, n_bmp_div_pixel( a,r,g,b, avr ), blend );
}

u32
n_bmp_sharpen_pixel( n_bmp *bmp, s32 x, s32 y, double blend )
{

	u32 color, center;
	int a,r,g,b;


	if (
		( false == n_bmp_ptr_get( bmp, x, y, &center ) )
		&&
		( false == n_bmp_is_trans( bmp, center ) )
	)
	{

		a = n_bmp_a( center );
		r = n_bmp_r( center );
		g = n_bmp_g( center );
		b = n_bmp_b( center );

	} else {

		return n_bmp_trans;

	}


	if (
		( false == n_bmp_ptr_get( bmp, x, y - 1, &color ) )
		&&
		( false == n_bmp_is_trans( bmp, color ) )
	)
	{

		a += (int) n_bmp_a( center ) - n_bmp_a( color );
		r += (int) n_bmp_r( center ) - n_bmp_r( color );
		g += (int) n_bmp_g( center ) - n_bmp_g( color );
		b += (int) n_bmp_b( center ) - n_bmp_b( color );

	}

	if (
		( false == n_bmp_ptr_get( bmp, x, y + 1, &color ) )
		&&
		( false == n_bmp_is_trans( bmp, color ) )
	)
	{

		a += (int) n_bmp_a( center ) - n_bmp_a( color );
		r += (int) n_bmp_r( center ) - n_bmp_r( color );
		g += (int) n_bmp_g( center ) - n_bmp_g( color );
		b += (int) n_bmp_b( center ) - n_bmp_b( color );

	}

	if (
		( false == n_bmp_ptr_get( bmp, x - 1, y, &color ) )
		&&
		( false == n_bmp_is_trans( bmp, color ) )
	)
	{

		a += (int) n_bmp_a( center ) - n_bmp_a( color );
		r += (int) n_bmp_r( center ) - n_bmp_r( color );
		g += (int) n_bmp_g( center ) - n_bmp_g( color );
		b += (int) n_bmp_b( center ) - n_bmp_b( color );

	}

	if (
		( false == n_bmp_ptr_get( bmp, x + 1, y, &color ) )
		&&
		( false == n_bmp_is_trans( bmp, color ) )
	)
	{

		a += (int) n_bmp_a( center ) - n_bmp_a( color );
		r += (int) n_bmp_r( center ) - n_bmp_r( color );
		g += (int) n_bmp_g( center ) - n_bmp_g( color );
		b += (int) n_bmp_b( center ) - n_bmp_b( color );

	}


	a = n_bmp_clamp_channel( a );
	r = n_bmp_clamp_channel( r );
	g = n_bmp_clamp_channel( g );
	b = n_bmp_clamp_channel( b );


	return n_bmp_blend_pixel( center, n_bmp_argb( a,r,g,b ), blend );
}

u32
n_bmp_gamma_pixel( u32 color, double gamma )
{

	// [Mechanism]
	//
	//	gamma = 0.0 : black
	//	gamma = 1.0 : nothing to do
	//	gamma = 2.0 : white


	// [!] : FORMULA : pow( 0.0=>1.0, gamma_from / gamma_to );


	// [!] : nothing to do

	if ( gamma == 1.0 ) { return color; }


	// [!] : precalc

	if ( gamma < 0.0 ) { gamma = 0.0; }
	if ( gamma > 2.0 ) { gamma = 2.0; }

	if ( gamma < 1.0 )
	{
		gamma = 1.0 / gamma;
	} else {
		gamma = gamma -  2.0;
		gamma = gamma * -1.0;
	}


	// [!] : alpha is reserved

	double a = n_bmp_a( color );
	double r = n_bmp_r( color );
	double g = n_bmp_g( color );
	double b = n_bmp_b( color );

	// [!] : 30% faster

	if ( ( r == g )&&( g == b ) )
	{
		r = g = b = 255.0 * pow( r * n_bmp_coeff_channel, gamma );
	} else
	if ( r == g )
	{
		r = 255.0 * pow( r * n_bmp_coeff_channel, gamma );
		g = r;
		b = 255.0 * pow( b * n_bmp_coeff_channel, gamma );
	} else
	if ( g == b )
	{
		r = 255.0 * pow( r * n_bmp_coeff_channel, gamma );
		g = 255.0 * pow( g * n_bmp_coeff_channel, gamma );
		b = g;
	} else {

		r = 255.0 * pow( r * n_bmp_coeff_channel, gamma );
		g = 255.0 * pow( g * n_bmp_coeff_channel, gamma );
		b = 255.0 * pow( b * n_bmp_coeff_channel, gamma );
	}


	return n_bmp_argb( a,r,g,b );
}

// internal
inline u32
n_bmp_bilinear_pixel_x( n_bmp *bmp, s32 fx, s32 fy, double ratio_x, double coeff_x )
{

	// [!] : comment-out for performance

	//if ( false == n_bmp_ptr_is_accessible( bmp, fx,fy ) ) { return color_trans; }


	u32 ret; n_bmp_ptr_get_fast( bmp, fx,fy, &ret );
	if ( n_bmp_is_trans( bmp, ret ) ) { return ret; }


	if ( ratio_x <= 0.0 )
	{

		// [!] : nearest neighbor

	} else
	if ( true )//( ratio_x > 1.0 )
	{

		// [!] : enlarge

		if ( ( fx + 1 ) < N_BMP_SX( bmp ) )
		{
			u32 clr; n_bmp_ptr_get_fast( bmp, fx + 1,fy, &clr );
			if ( false == n_bmp_is_trans( bmp, clr ) )
			{
				ret = n_bmp_blend_pixel( ret, clr, coeff_x );
			}
		}

	} else
	if ( ratio_x < 1.0 )
	{
/*
		// [!] : shrink

		// [x] : this logic causes block-noise

		double n = 1.0 / ratio_x;

		int x = 1;
		while( 1 )
		{

			u32 clr;
			if ( false == n_bmp_ptr_get( bmp, fx + x,fy, &clr ) )
			{
				ret = n_bmp_blend_pixel( ret, clr, 0.5 );
			}

			x++;
			if ( x >= n ) { break; }
		}

		if ( n != trunc( n ) )
		{
			u32 clr;
			if ( false == n_bmp_ptr_get( bmp, fx + x,fy, &clr ) )
			{
				ret = n_bmp_blend_pixel( ret, clr, n - trunc( n ) );
			}
		}
*/
	}


	return ret;
}

u32
n_bmp_bilinear_pixel
(
	n_bmp  *bmp,
	s32          fx, s32         fy,
	double  ratio_x, double ratio_y,
	double  coeff_x, double coeff_y
)
{

	// [!] : comment-out for performance

	//if ( false == n_bmp_ptr_is_accessible( bmp, fx,fy ) ) { return color_trans; }


	u32 ret = n_bmp_bilinear_pixel_x( bmp, fx,fy, ratio_x, coeff_x );
	if ( n_bmp_is_trans( bmp, ret ) ) { return ret; }


	if ( ratio_y <= 0.0 )
	{

		// [!] : nearest neighbor

	} else
	if ( true )//( ratio_y > 1.0 )
	{

		// [!] : enlarge

		if ( ( fy + 1 ) < N_BMP_SY( bmp ) )
		{
			u32 clr = n_bmp_bilinear_pixel_x( bmp, fx,fy + 1, ratio_x, coeff_x );
			if ( false == n_bmp_is_trans( bmp, clr ) )
			{
				ret = n_bmp_blend_pixel( ret, clr, coeff_y );
			}
		}

	} else
	if ( ratio_y < 1.0 )
	{
/*
		// [!] : shrink

		// [x] : this logic causes block-noise

		double n = 1.0 / ratio_y;

		int y = 1;
		while( 1 )
		{

			u32 clr = n_bmp_bilinear_pixel_x( bmp, fx,fy + y, ratio_x, coeff_x );
			if ( false == n_bmp_is_trans( bmp, clr ) )
			{
				ret = n_bmp_blend_pixel( ret, clr, 0.5 );
			}

			y++;
			if ( y >= n ) { break; }
		}

		if ( n != trunc( n ) )
		{
			u32 clr = n_bmp_bilinear_pixel_x( bmp, fx,fy + y, ratio_x, coeff_x );
			if ( false == n_bmp_is_trans( bmp, clr ) )
			{
				ret = n_bmp_blend_pixel( ret, clr, n - trunc( n ) );
			}
		}
*/
	}


	return ret;
}

#define n_bmp_ahsl n_bmp_argb
#define n_bmp_hsl  n_bmp_rgb

#define n_bmp_h n_bmp_r
#define n_bmp_s n_bmp_g
#define n_bmp_l n_bmp_b

#define n_bmp_hue        n_bmp_r
#define n_bmp_saturation n_bmp_g
#define n_bmp_lightness  n_bmp_b

inline double
n_bmp_ahsl2argb_channel( double min, double max, double c )
{

	// [!] : 1% faster than division

	const double coef = 1.0f / 60.0f;


	if ( c <  60.0 ) { c = min + ( ( ( max - min ) *           c   ) * coef ); } else
	if ( c < 180.0 ) { c = max;                                                } else
	if ( c < 240.0 ) { c = min + ( ( ( max - min ) * ( 240.0 - c ) ) * coef ); } else { c = min; }


	return c;
}

u32
n_bmp_ahsl2argb( u32 hsl )
{

	double a = (double) n_bmp_a( hsl );
	double h = (double) n_bmp_h( hsl ) * n_bmp_coeff_channel;
	double s = (double) n_bmp_s( hsl ) * n_bmp_coeff_channel;
	double l = (double) n_bmp_l( hsl ) * n_bmp_coeff_channel;


	double min,max;

	if ( l <= 0.5 )
	{
		max = ( l * ( 1.0 + s ) );
	} else {
		max = ( l * ( 1.0 - s ) ) + s;
	}

	min = ( 2 * l ) - max;


//n_posix_debug_literal( "%f %f %f", h,s,l );

	double r,g,b;

	if ( s == 0.0 )
	{

		r = g = b = l;

	} else {

		h *= 360;

		r = h + 120.0;
		g = h;
		b = h - 120.0;

		if ( r >= 360.0 ) { r -= 360.0; }
		if ( b <    0.0 ) { b += 360.0; }

		r = n_bmp_ahsl2argb_channel( min, max, r );
		g = n_bmp_ahsl2argb_channel( min, max, g );
		b = n_bmp_ahsl2argb_channel( min, max, b );

	}


	// Normalization

	r *= 255.0;
	g *= 255.0;
	b *= 255.0;


	return n_bmp_argb( a,r,g,b );
}

u32
n_bmp_argb2ahsl( u32 color )
{

	// [!] : range of return value : 0 => 255

	double a = (double) n_bmp_a( color );
	double r = (double) n_bmp_r( color ) * n_bmp_coeff_channel;
	double g = (double) n_bmp_g( color ) * n_bmp_coeff_channel;
	double b = (double) n_bmp_b( color ) * n_bmp_coeff_channel;


	// [!] : this code is slower than below : 0.5%

	//double min = n_posix_min_double( r, n_posix_min_double( g, b ) );
	//double max = n_posix_max_double( r, n_posix_max_double( g, b ) );

	double min,max;
	min = max = r;

	if ( min > g ) { min = g; }
	if ( min > b ) { min = b; }

	if ( max < g ) { max = g; }
	if ( max < b ) { max = b; }


	// Hue

	double h = 0.0;

	if ( max == min )
	{

		h = 0.0;

	} else
	if ( max == r )
	{

		h = 60.0 * ( ( g - b ) / ( max - min ) );
		h = fmod( h, 360.0 );

	} else
	if ( max == g )
	{

		h = 60.0 * ( ( b - r ) / ( max - min ) );
		h = h + 120.0;

	} else
	if ( max == b )
	{

		h = 60.0 * ( ( r - g ) / ( max - min ) );
		h = h + 240.0;

	}


	// Lightness

	double l = ( max + min ) / 2.0;


	// Saturation

	double s = 0;

	if ( max == min )
	{
		//s = 0;
	} else
	if ( l <= 0.5 )
	{
		s = ( max - min ) / ( max + min );
	} else {
		s = ( max - min ) / ( 2.0 - ( max + min ) );
	}


	// Normalization

//n_posix_debug_literal( "%f %f %f", h,s,l );

	h *= 1.0f / 360.0f;
	//h /= 360.0;

	h *= 255.0;
	s *= 255.0;
	l *= 255.0;


	return n_bmp_ahsl( a, h, s, l );
}

#define n_bmp_hue_wheel_tweak_pixel( color, h ) n_bmp_hsl_tweak_pixel( color, h, 0, 0 )
#define n_bmp_vividness_tweak_pixel( color, s ) n_bmp_hsl_tweak_pixel( color, 0, s, 0 )
#define n_bmp_lightness_tweak_pixel( color, l ) n_bmp_hsl_tweak_pixel( color, 0, 0, l )

u32
n_bmp_hsl_tweak_pixel( u32 color, int hue, int saturation, int lightness )
{

	color = n_bmp_argb2ahsl( color );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );


	// [!] : saturation : no touch when grayscale

	h = n_bmp_clamp_channel( h + hue );
	if ( s != 0 ) { s = n_bmp_clamp_channel( s + saturation ); }
	l = n_bmp_clamp_channel( l + lightness );


	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

#define n_bmp_hue_wheel_replace_pixel( color, h ) n_bmp_hsl_replace_pixel( color,  h, -1, -1 )
#define n_bmp_vividness_replace_pixel( color, s ) n_bmp_hsl_replace_pixel( color, -1,  s, -1 )
#define n_bmp_lightness_replace_pixel( color, l ) n_bmp_hsl_replace_pixel( color, -1, -1,  l )

u32
n_bmp_hsl_replace_pixel( u32 color, int hue, int saturation, int lightness )
{

	color = n_bmp_argb2ahsl( color );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );

	if ( hue        != -1 ) { h =        hue; }
	if ( saturation != -1 ) { s = saturation; }
	if ( lightness  != -1 ) { l =  lightness; }

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

#define n_bmp_composite_pixel( u, l, x_u, y_u, x_l, y_l, b ) n_bmp_composite_pixel_fast( u, l, x_u, y_u, x_l, y_l, b, NULL ) 

static bool n_bmp_composite_pixel_finalize = true;

inline u32
n_bmp_composite_pixel_fast
(
	const n_bmp *bmp_upper,
	const n_bmp *bmp_lower,
	s32 x_upper, s32 y_upper,
	s32 x_lower, s32 y_lower,
	double blend,
	bool *write_needed
)
{

	// [!] : no error ckecking for performance


	u32 color_upper; n_bmp_ptr_get_fast( bmp_upper, x_upper,y_upper, &color_upper );
	if ( n_bmp_is_trans( bmp_upper, color_upper ) )
	{
		if ( write_needed != NULL ) { (*write_needed) = false; }
		return color_upper;
	}

	int alpha_upper = n_bmp_a( color_upper );


	bool perpixel = ( alpha_upper != N_BMP_ALPHA_CHANNEL_VISIBLE );
	bool global   = ( blend != 0.0 );

	if ( ( perpixel == false )&&( global == false ) )
	{
		if ( write_needed != NULL ) { (*write_needed) = true; }
		return color_upper;
	}


	u32 color_lower; n_bmp_ptr_get_fast( bmp_lower, x_lower,y_lower, &color_lower );


	if ( perpixel )
	{

//f = n_bmp_blend_pixel( f, t, n_bmp_blend_alpha2ratio( alpha_upper ) );

		if ( alpha_upper == N_BMP_ALPHA_CHANNEL_INVISIBLE )
		{

			color_upper = color_lower;

		} else {
//color_upper = n_bmp_blend_pixel( color_upper, color_lower, n_bmp_blend_alpha2ratio( alpha_upper ) );

			// [!] : finalize : alpha will be fully resolved

			if ( n_bmp_composite_pixel_finalize )
			{
				if ( N_BMP_ALPHA_CHANNEL_VISIBLE != n_bmp_a( color_lower ) )
				{
//color_upper = n_bmp_black;
					double ratio = n_bmp_blend_alpha2ratio( alpha_upper );
					color_upper  = n_bmp_blend_pixel( color_upper, color_lower, ratio );
				} else {
					double ratio = n_bmp_blend_alpha2ratio( alpha_upper );
					color_upper  = n_bmp_alpha_visible_pixel( color_upper );
					color_upper  = n_bmp_blend_pixel( color_upper, color_lower, ratio );
				}
			}

		}

	}


	if ( global ) { color_upper = n_bmp_blend_pixel( color_upper, color_lower, blend ); }


	if ( write_needed != NULL )
	{
		(*write_needed) = ( color_upper != color_lower );
	} 


	return color_upper;
}


#endif //_H_NONNON_NEUTRAL_BMP_COLOR

