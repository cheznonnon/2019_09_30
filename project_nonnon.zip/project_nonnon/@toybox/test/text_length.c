


//#define UNICODE




#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );


		n_win_text_set_literal( hwnd, "Test" );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_LBUTTONDOWN :
	{

		int           cch = n_win_text_len( hwnd );
		n_posix_char *str = n_string_new( cch ); n_win_text_get( hwnd, str, cch + 1 );

		n_posix_debug_literal( " %d : %s ", cch, str );

		n_memory_free( str );

	}
	break;


	case WM_CLOSE :

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

