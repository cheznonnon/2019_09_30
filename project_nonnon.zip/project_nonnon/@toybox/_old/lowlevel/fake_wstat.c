



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>


#include <windows.h>




#define s8           char
#define s16          short
#define s32          long
#define s64          long long

#define u8  unsigned char
#define u16 unsigned short
#define u32 unsigned long
#define u64 unsigned long long




#define mb(s) MessageBox(NULL, s, "", 0)




int
main(int argc, char *argv[])
{

	struct stat info;

	HANDLE   h;
	FILETIME create, access, modify;
	u32      size;
	u32      tmp32;
	u64      tmp64;


	h = CreateFile(
		argv[1],
		GENERIC_READ,
		0, NULL,
		OPEN_ALWAYS,
		0,0 );

	GetFileTime( h, &create, &access, &modify );

	size = GetFileSize( h, &tmp32 );

	CloseHandle( h );


	stat( argv[1], &info );

	tmp64  = (u64) create.dwLowDateTime;
	tmp64 += ( (u64) create.dwHighDateTime ) << 32;
	tmp64 -= 116444736000000000ULL;
	tmp64 /= 10000000ULL;


	char str[ 1000 ];
	sprintf( str, "%d : %d", (int) tmp64, (int) info.st_ctime );
	mb( str );



	sprintf( str, "%d : %d", (int) size, (int) info.st_size );
	mb( str );


	return 0;
}

