// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_oc_item_progressbar_reset( n_oc_item_progressbar *p, int mode )
{

	p->phase      = N_ORANGECAT_PROGRESS_NONE;
	p->onoff      = false;
	p->first      = true;

	p->redraw_lct = 0;
	p->redraw_prv = 0;
	p->redraw_cur = 0;
	p->redraw_pos = 0;


	n_ITaskbarList_stop( oc.ITaskbarList3, game.hwnd );


	n_ITaskbarList_mode( oc.ITaskbarList3, game.hwnd, mode );

	if ( mode == N_ITASKBARLIST_MODE_GREEN  )
	{
		p->color = oc_color.item_gauge;
	} else
	if ( mode == N_ITASKBARLIST_MODE_YELLOW )
	{
		p->color = oc_color.item_copy;
	} else
	if ( mode == N_ITASKBARLIST_MODE_RED    )
	{
		p->color = oc_color.item_copy;
	}// else


	return;
}

void
n_oc_item_progressbar_main( n_oc_item_progressbar *p, int loaded, int count )
{
//return;

	if ( oc.exit_onoff ) { return; }


	// [!] : for 100%

//n_game_hwndprintf_literal( " %d : %d / %d ", p->phase, loaded, count );
//return;

	if ( loaded != count )
	{
		if ( p->phase == N_ORANGECAT_PROGRESS_NONE ) { p->phase = N_ORANGECAT_PROGRESS_INIT; }
	} else {
		if ( p->phase == N_ORANGECAT_PROGRESS_INIT ) { p->phase = N_ORANGECAT_PROGRESS_100P; }
	}

	if ( p->phase )
	{

		if ( p->onoff == false )
		{
			p->onoff = true;

			if ( p->first ) { p->first = false; p->redraw_lct = loaded; }

			p->redraw_prv = (double) p->redraw_lct / count;
			p->redraw_cur = (double)    loaded     / count;
			p->redraw_pos = 0;

			n_ITaskbarList_stop( oc.ITaskbarList3, game.hwnd );
			n_ITaskbarList_loop( oc.ITaskbarList3, game.hwnd, loaded, count );

			item.sync_progressbar_animation_onoff = true;
			n_game_progressbar_animation          = N_GAME_PROGRESSBAR_ANIMATION_ON_UP;
		}

		if ( p->onoff )
		{

			s32 f = (double) item.sx * p->redraw_prv;
			s32 t = (double) item.sx * p->redraw_cur;

			s32  x = 0;
			s32  y = oc.unit_path;
			s32 sx = f;
			s32 sy = oc.unit_scal;

			n_bmp_box( &game.bmp, x,y,sx+p->redraw_pos,sy, p->color );

			p->redraw_pos += n_posix_max_s32( 1, item.sx / 100 );
			if ( ( f + p->redraw_pos ) > t )
			{
				p->onoff = false;

				p->redraw_lct = loaded;
				p->redraw_prv = 0;
				p->redraw_cur = 0;
				p->redraw_pos = 0;

				n_ITaskbarList_loop( oc.ITaskbarList3, game.hwnd, loaded, count );

				if ( p->phase == N_ORANGECAT_PROGRESS_100P )
				{

					p->phase = N_ORANGECAT_PROGRESS_LAST;
					p->timer = n_posix_tickcount();

				} else
				if ( p->phase == N_ORANGECAT_PROGRESS_LAST )
				{

					if ( n_game_timer( &p->timer, N_ORANGECAT_INTERVAL_PBAR ) )
					{

						p->phase = N_ORANGECAT_PROGRESS_NONE;
						p->first = true;

						n_ITaskbarList_stop( oc.ITaskbarList3, game.hwnd );

						item.sync_progressbar_animation_onoff = false;
						n_game_progressbar_animation          = N_GAME_PROGRESSBAR_ANIMATION_OFF;

						n_bmp_box( &game.bmp, x,y,item.sx,sy, oc_color.bg );

					} else {

						n_bmp_box( &game.bmp, x,y,item.sx,sy, p->color );

					}

				}

			}

			n_game_on_paint_partial( x,y,item.sx,sy );

		}

		if ( item.sync_progressbar_animation_onoff )
		{
			n_bmp_free( &oc.scrollbar.bmp_th );
			n_win_scrollbar_draw_always( &oc.scrollbar, true );

			//n_win_scrollbar_rect r = oc.scrollbar.rect_main;
			//n_game_on_paint_partial( r.x,r.y,r.sx,r.sy );
		}

	}


	return;
}


