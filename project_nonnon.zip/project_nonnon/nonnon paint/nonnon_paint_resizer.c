// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/neutral/bmp.c"
#include "../nonnon/neutral/bmp/all.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_combobox.c"
#include "../nonnon/win32/win_inputpopup.c"
#include "../nonnon/win32/win_scroller.c"
#include "../nonnon/win32/win_separator.c"
#include "../nonnon/win32/win_txtbox.c"


#include "../nonnon/project/macro.c"




// rc.h

#define H_LBL_RESIZE    n_paint_resizer_hgui[  0 ]
#define H_LBL_SIZE      n_paint_resizer_hgui[  1 ]
#define H_LINE          n_paint_resizer_hgui[  2 ]
#define H_LBL_COLOR     n_paint_resizer_hgui[  3 ]
#define H_BUTTON        n_paint_resizer_hgui[  4 ]
#define GUI_MAX                                5

#define H_INPUT_SX      ( &n_paint_resizer_htxt[  0 ] )
#define H_INPUT_SY      ( &n_paint_resizer_htxt[  1 ] )
#define TXT_MAX                                   2

#define H_CMB_RESIZE    ( &n_paint_resizer_hcmb[  0 ] )
#define H_CMB_COLOR     ( &n_paint_resizer_hcmb[  1 ] )
#define CMB_MAX                                   2

#define H_SCR_ROUND     ( &n_paint_resizer_hscr[  0 ] )
#define H_SCR_GAMMA     ( &n_paint_resizer_hscr[  1 ] )
#define H_SCR_CLRWH     ( &n_paint_resizer_hscr[  2 ] )
#define H_SCR_VIVID     ( &n_paint_resizer_hscr[  3 ] )
#define H_SCR_SHARP     ( &n_paint_resizer_hscr[  4 ] )
#define H_SCR_CTRST     ( &n_paint_resizer_hscr[  5 ] )
#define SCR_MAX                                   6




#define MSG_SIZE                    "Size"
#define MSG_RESIZE                  "Resize Option"
#define MSG_RESIZE_TOPLEFT          "Top-Left"
#define MSG_RESIZE_TILE             "Tile"
#define MSG_RESIZE_CENTER           "Center"
#define MSG_RESIZE_TRANSFORM        "Transform"
#define MSG_RESIZE_FIT_X            "Fit : Lock X"
#define MSG_RESIZE_FIT_Y            "Fit : Lock Y"
#define MSG_RESIZE_SYMMETRY_L_TO_R  "Symmetry : Left to Right"
#define MSG_RESIZE_SYMMETRY_R_TO_L  "Symmetry : Right to Left"
#define MSG_ROUND                   "Round"
#define MSG_COLOR                   "Color Option"
#define MSG_COLOR_NONE              "None"
#define MSG_COLOR_GRAY              "Grayscale"
#define MSG_COLOR_MONO              "Monochrome"
#define MSG_COLOR_MASK              "Noise Removal Mask"
#define MSG_COLOR_SIZE              "Color Reduction"
#define MSG_GAMMA                   "Gamma"
#define MSG_CLRWH                   "Color Wheel"
#define MSG_VIVID                   "Vividness"
#define MSG_SHARP                   "Sharpness"
#define MSG_CTRST                   "Contrast"




// window

static HWND           n_paint_resizer_hgui[ GUI_MAX ];
static n_win_scroller n_paint_resizer_hscr[ SCR_MAX ];
static n_win_combo    n_paint_resizer_hcmb[ CMB_MAX ];
static n_win_txtbox   n_paint_resizer_htxt[ TXT_MAX ];


// app

static int n_paint_resizer_round;
static int n_paint_resizer_gamma;
static int n_paint_resizer_clrwh;
static int n_paint_resizer_vivid;
static int n_paint_resizer_sharp;
static int n_paint_resizer_ctrst;


static bool n_paint_resizer_scroll_init = true;




// internal
void
n_paint_resizer_go( void )
{

	n_posix_char *str_resize = n_win_combo_selection_get( H_CMB_RESIZE );


	if (
		( n_string_is_same_literal( MSG_RESIZE_SYMMETRY_L_TO_R, str_resize ) )
		||
		( n_string_is_same_literal( MSG_RESIZE_SYMMETRY_R_TO_L, str_resize ) )
	)
	{

		s32 x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{

			sx = N_BMP_SX( &n_paint_bmp_data ) / 2;
			sy = N_BMP_SY( &n_paint_bmp_data );

			s32 ox;
			if ( n_string_is_same_literal( MSG_RESIZE_SYMMETRY_L_TO_R, str_resize ) )
			{
				 x = sx;
				ox =  0;
			} else {
				 x =  0;
				ox = sx;
			}

			 y =  0;
			fx =  x;
			fy =  y;

			grabber = N_PAINT_GRABBER_DRAG_OK;

			n_bmp_new_fast( &n_paint_bmp_grab, sx,sy );
			n_bmp_fastcopy( &n_paint_bmp_data, &n_paint_bmp_grab, ox,0,sx,sy, 0,0 );
			n_bmp_flush_mirror( &n_paint_bmp_grab, N_BMP_MIRROR_LEFTSIDE_RIGHT );

		} else
		if ( N_PAINT_GRABBER_IS_DRAG_OK() )
		{

			n_bmp_flush_mirror( &n_paint_bmp_grab, N_BMP_MIRROR_LEFTSIDE_RIGHT );

			s32 tsx = N_BMP_SX( &n_paint_bmp_data ) / 2;

			if ( n_string_is_same_literal( MSG_RESIZE_SYMMETRY_L_TO_R, str_resize ) )
			{
				if ( x < tsx ) { x = fx = tsx + ( tsx - x ) - sx; }
			} else {
				if ( x > tsx ) { x = fx = tsx - ( x - tsx ) - sx; }
			}

		}

		n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


		n_paint_grabber_resync_auto();


		return;
	}


	n_bmp b;

	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{
		n_bmp_carboncopy( &n_paint_bmp_data, &b );
	} else {
		n_bmp_carboncopy( &n_paint_bmp_grab, &b );
	}


	n_posix_char str_size[ 100 ];
	s32 sx,sy;

	n_win_txtbox_selection_get( H_INPUT_SX, str_size ); sx = n_posix_atoi( str_size );
	n_win_txtbox_selection_get( H_INPUT_SY, str_size ); sy = n_posix_atoi( str_size );

	if ( sx == 0 ) { sx = N_BMP_SX( &b ); }
	if ( sy == 0 ) { sy = N_BMP_SY( &b ); }


	if ( n_string_is_same_literal( MSG_RESIZE_TRANSFORM, str_resize ) )
	{
		n_bmp_resampler
		(
			&b,
			(double) sx / N_BMP_SX( &b ),
			(double) sy / N_BMP_SY( &b )
		);
	} else
	if ( n_string_is_same_literal( MSG_RESIZE_FIT_X, str_resize ) )
	{

		double ratio = (double) sx / N_BMP_SX( &b );

		n_bmp_resampler( &b, ratio, ratio );

	} else
	if ( n_string_is_same_literal( MSG_RESIZE_FIT_Y, str_resize ) )
	{

		double ratio = (double) sy / N_BMP_SY( &b );

		n_bmp_resampler( &b, ratio, ratio );

	} else {

		int ret = 0;

		if ( n_string_is_same_literal( MSG_RESIZE_TOPLEFT, str_resize ) )
		{
			ret = N_BMP_RESIZER_NORMAL;
		}
		if ( n_string_is_same_literal( MSG_RESIZE_TILE,    str_resize ) )
		{
			ret = N_BMP_RESIZER_TILE;
		}
		if ( n_string_is_same_literal( MSG_RESIZE_CENTER,  str_resize ) )
		{
			ret = N_BMP_RESIZER_CENTER;
		}

		n_bmp_resizer( &b, sx,sy, n_bmp_white, ret );

	}


	{ // Rotate

		n_bmp_matrix_rotate( &b, n_paint_resizer_round, n_bmp_white_invisible, true );

	}


	{ // Color Option

		n_posix_char *str_color = n_win_combo_selection_get( H_CMB_COLOR );

		if ( n_string_is_same_literal( MSG_COLOR_GRAY, str_color ) )
		{
			n_bmp_flush_grayscale( &b );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_MONO, str_color ) )
		{
			n_bmp_flush_monochrome( &b );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_MASK, str_color ) )
		{
			n_bmp_flush_reducer( &b, 10 );
			n_bmp_flush_monochrome( &b );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_SIZE, str_color ) )
		{
			n_bmp_flush_reducer( &b, 4 );
		}// else

	}


	{ // Gamma

		// [!] : shortcut for performance

		double g = (double) n_paint_resizer_gamma / 10.0;

		if ( g == 0.0 ) { n_bmp_flush( &b, n_bmp_black ); } else
		if ( g == 2.0 ) { n_bmp_flush( &b, n_bmp_white ); } else
		if ( g != 1.0 ) { n_bmp_flush_gamma( &b, g );     }

	}


	{ // Color Wheel & Vividness

		int h = n_paint_resizer_clrwh - 128;
		int s = n_paint_resizer_vivid - 100;
		int l = 0;

		n_bmp_flush_tweaker_hsl( &b, h, s, l );

	}


	{ // Sharpness

		int s = n_paint_resizer_sharp - 100;


		if ( s > 0 )
		{
			n_bmp_flush_sharpen  ( &b, (double) s * 0.01 );
		} else
		if ( s < 0 )
		{
			s *= -1;
			n_bmp_flush_antialias( &b, (double) s * 0.01 );
		}

	}


	{ // Contrast

		n_bmp_flush_contrast( &b, n_paint_resizer_ctrst );

	}


	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{

		n_bmp_free_fast( &n_paint_bmp_data );
		n_bmp_alias( &b, &n_paint_bmp_data );

		n_paint_refresh_all();

		n_paint_title();

	} else {

		n_paint_grabber_select( &b, true );
		n_bmp_free( &b );

	}


	return;
}

// internal
void
n_paint_resizer_inputfield_set( void )
{

	s32 sx,sy;


	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{
		sx = N_BMP_SX( &n_paint_bmp_data );
		sy = N_BMP_SY( &n_paint_bmp_data );
	} else {
		sx = N_BMP_SX( &n_paint_bmp_grab );
		sy = N_BMP_SY( &n_paint_bmp_grab );
	}


	n_posix_char str_sx[ 100 ];
	n_posix_char str_sy[ 100 ];

	n_posix_sprintf_literal( str_sx, "%ld", sx );
	n_posix_sprintf_literal( str_sy, "%ld", sy );

	n_win_txtbox_line_set( H_INPUT_SX, 0, str_sx );
	n_win_txtbox_line_set( H_INPUT_SY, 0, str_sy );

	n_win_txtbox_select_tail_set( H_INPUT_SX );
	n_win_txtbox_select_tail_set( H_INPUT_SY );


	return;
}
void
n_paint_resizer_on_size( HWND hwnd, int nwin, bool redraw )
{

	s32 ctl,m; n_win_stdsize( hwnd, &ctl, NULL, &m );


	s32 dpi   = n_win_dpi( hwnd );
	s32 scale = dpi / 96;


	s32 csy = ( ctl * 11 );
	s32 csx = (double) csy * sqrt( 2 );


	s32 patch_csx = csx + m;
	s32 patch_csy = csy + m;

	n_win_set_patch( hwnd, &patch_csx, &patch_csy, 7, 7 );

	n_win_set( hwnd, NULL, patch_csx,patch_csy, nwin );


	s32 btnsx = csx;
	s32 sx1_2 = csx / 2;
	s32 sx1_4 = csx / 4;
	s32 sx3_4 = csx / 4 * 3;
	s32 cmbsx = csx - sx1_2;
	s32 inpsx = csx - sx3_4;
	s32 ln_sx = csx - m;

	s32 x = scale;

	if ( scale != 1 ) { btnsx -= scale; }

	//if ( dpi == 96 )
	{
		csx--;
		cmbsx--;
		inpsx--;
	}

	n_win_move      ( H_LBL_RESIZE,         x,ctl* 0, sx1_2,ctl, redraw );
	n_win_combo_move( H_CMB_RESIZE,     sx1_2,ctl* 0, cmbsx,csy,   true );
	n_win_move      ( H_LBL_SIZE,           x,ctl* 1, sx1_2,ctl, redraw );
	n_win_move      ( H_INPUT_SX->hwnd, sx1_2,ctl* 1, sx1_4,ctl, redraw );
	n_win_move      ( H_INPUT_SY->hwnd, sx3_4,ctl* 1, inpsx,ctl, redraw );
	nwscr_move      ( H_SCR_ROUND,          x,ctl* 2,   csx,ctl, redraw );
	n_win_move      ( H_LINE,               x,ctl* 3, ln_sx,ctl, redraw );
	n_win_move      ( H_LBL_COLOR,          x,ctl* 4, sx1_2,ctl, redraw );
	n_win_combo_move( H_CMB_COLOR,      sx1_2,ctl* 4, cmbsx,csy,   true );
	nwscr_move      ( H_SCR_GAMMA,          x,ctl* 5,   csx,ctl, redraw );
	nwscr_move      ( H_SCR_CLRWH,          x,ctl* 6,   csx,ctl, redraw );
	nwscr_move      ( H_SCR_VIVID,          x,ctl* 7,   csx,ctl, redraw );
	nwscr_move      ( H_SCR_SHARP,          x,ctl* 8,   csx,ctl, redraw );
	nwscr_move      ( H_SCR_CTRST,          x,ctl* 9,   csx,ctl, redraw );
	n_win_move      ( H_BUTTON,             x,ctl*10, btnsx,ctl, redraw );


	return;
}

void
n_paint_resizer_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, 500 );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, true );


		n_win_stdfont_init( n_paint_resizer_hgui, GUI_MAX );


		n_win_refresh( H_LBL_RESIZE, true );
		n_win_combo_on_settingchange( H_CMB_RESIZE );

		n_win_refresh( H_LBL_SIZE, true );

		n_win_txtbox_on_settingchange( H_INPUT_SX );
		n_win_txtbox_on_settingchange( H_INPUT_SY );

		n_win_scroller_on_settingchange( H_SCR_ROUND );

		n_win_refresh( H_LINE     , true );
		n_win_refresh( H_LBL_COLOR, true );

		n_win_combo_on_settingchange( H_CMB_COLOR );

		n_win_scroller_on_settingchange( H_SCR_GAMMA );
		n_win_scroller_on_settingchange( H_SCR_CLRWH );
		n_win_scroller_on_settingchange( H_SCR_VIVID );
		n_win_scroller_on_settingchange( H_SCR_SHARP );
		n_win_scroller_on_settingchange( H_SCR_CTRST );

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BUTTON );

	break;


	} // switch


}
 
LRESULT CALLBACK
n_paint_resizer_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND         target_input =  NULL;
	static n_win_combo *target_combo =  NULL;
	static UINT         target_timer =     0;


	n_paint_resizer_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_win_combo_zero( H_CMB_RESIZE );
		n_win_combo_zero( H_CMB_COLOR  );

		n_win_scroller_zero( H_SCR_ROUND );
		n_win_scroller_zero( H_SCR_GAMMA );
		n_win_scroller_zero( H_SCR_CLRWH );
		n_win_scroller_zero( H_SCR_VIVID );
		n_win_scroller_zero( H_SCR_SHARP );
		n_win_scroller_zero( H_SCR_CTRST );

		n_win_txtbox_zero( H_INPUT_SX );
		n_win_txtbox_zero( H_INPUT_SY );


		// Window

		n_win_init_literal( hwnd, "Resizer", "", "" );

		n_win_gui_literal( hwnd, LABEL,   MSG_RESIZE, &H_LBL_RESIZE );
		n_win_gui_literal( hwnd, LABEL,     MSG_SIZE, &H_LBL_SIZE   );
		n_win_gui_literal( hwnd, CANVAS,          "", &H_LINE       );
		n_win_gui_literal( hwnd, LABEL,    MSG_COLOR, &H_LBL_COLOR  );
		n_win_gui_literal( hwnd, FBTN,            "", &H_BUTTON     );

		n_win_text_set( H_BUTTON, n_project_string_go );

		n_win_combo_init( H_CMB_RESIZE, hwnd );
		n_win_combo_init( H_CMB_COLOR , hwnd );

		{
			int style  = 0;

			style  |= N_WIN_TXTBOX_STYLE_ONELINE;

			int option = 0;

			option |= N_WIN_TXTBOX_OPTION_ONELINE_HCENTER;
			option |= N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL;

			n_win_txtbox_init( H_INPUT_SX, hwnd, style, option );
			n_win_txtbox_init( H_INPUT_SY, hwnd, style, option );

			n_win_property_init_literal( H_INPUT_SX->hwnd, "Number", true );
			n_win_property_init_literal( H_INPUT_SY->hwnd, "Number", true );
		}

		n_win_scroller_init_literal( H_SCR_ROUND, hwnd, MSG_ROUND );
		n_win_scroller_init_literal( H_SCR_GAMMA, hwnd, MSG_GAMMA );
		n_win_scroller_init_literal( H_SCR_CLRWH, hwnd, MSG_CLRWH );
		n_win_scroller_init_literal( H_SCR_VIVID, hwnd, MSG_VIVID );
		n_win_scroller_init_literal( H_SCR_SHARP, hwnd, MSG_SHARP );
		n_win_scroller_init_literal( H_SCR_CTRST, hwnd, MSG_CTRST );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		n_project_defaultbutton( H_BUTTON );
		SetFocus( H_BUTTON );

		n_win_iconbutton_init( hwnd, H_BUTTON );


		n_win_stdfont_init( n_paint_resizer_hgui, GUI_MAX );


		// Size

		n_paint_resizer_on_size( hwnd, N_WIN_SET_CENTERING, false );


		// Init

		n_paint_resizer_inputfield_set();


		n_txt_set_literal( &H_CMB_RESIZE->txt, 0, MSG_RESIZE_TOPLEFT   );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 1, MSG_RESIZE_TILE      );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 2, MSG_RESIZE_CENTER    );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 3, MSG_RESIZE_TRANSFORM );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 4, MSG_RESIZE_FIT_X     );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 5, MSG_RESIZE_FIT_Y     );

		if (
			( tooltype == N_PAINT_TOOL_TYPE_GRAB )
			&&
			(
				( N_PAINT_GRABBER_IS_NEUTRAL() )
				||
				( N_PAINT_GRABBER_IS_DRAG_OK() )
			)
		)
		{
			n_txt_set_literal( &H_CMB_RESIZE->txt, 0, MSG_RESIZE_SYMMETRY_L_TO_R  );
			n_txt_set_literal( &H_CMB_RESIZE->txt, 0, MSG_RESIZE_SYMMETRY_R_TO_L  );
		}

		n_win_combo_selection_set_by_string_literal( H_CMB_RESIZE, MSG_RESIZE_CENTER  );


		n_txt_set_literal( &H_CMB_COLOR->txt, 0, MSG_COLOR_NONE );
		n_txt_set_literal( &H_CMB_COLOR->txt, 1, MSG_COLOR_GRAY );
		n_txt_set_literal( &H_CMB_COLOR->txt, 2, MSG_COLOR_MONO );
		n_txt_set_literal( &H_CMB_COLOR->txt, 3, MSG_COLOR_MASK );
		n_txt_set_literal( &H_CMB_COLOR->txt, 4, MSG_COLOR_SIZE );

		n_win_combo_selection_set_by_string_literal( H_CMB_COLOR, MSG_COLOR_NONE );


		n_paint_resizer_scroll_init = true;

		n_paint_resizer_round = 360;
		n_paint_resizer_gamma =  10;
		n_paint_resizer_clrwh = 128;
		n_paint_resizer_vivid = 100;
		n_paint_resizer_sharp = 100;
		n_paint_resizer_ctrst =   0;

		n_win_scroller_scroll_parameter( H_SCR_ROUND, 1, 10, 720, n_paint_resizer_round, true );
		n_win_scroller_scroll_parameter( H_SCR_GAMMA, 1, 10,  20, n_paint_resizer_gamma, true );
		n_win_scroller_scroll_parameter( H_SCR_CLRWH, 1, 10, 256, n_paint_resizer_clrwh, true );
		n_win_scroller_scroll_parameter( H_SCR_VIVID, 1, 10, 200, n_paint_resizer_vivid, true );
		n_win_scroller_scroll_parameter( H_SCR_SHARP, 1, 10, 200, n_paint_resizer_sharp, true );
		n_win_scroller_scroll_parameter( H_SCR_CTRST, 1, 10, 256, n_paint_resizer_ctrst, true );

		n_paint_resizer_scroll_init = false;


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, false );
		EnableWindow( hwnd_main, false );

	break;


	case WM_SIZE :

		// [Needed] : non-DWM : scrollers disappear when combo is closed

		n_paint_resizer_on_size( hwnd, N_WIN_SET_DEFAULT, true );

	break;


	case WM_NCLBUTTONDOWN :
	case WM_LBUTTONDOWN   :

		SetFocus( hwnd );

	break;


	case WM_COMMAND :
	{
//break;
		HWND h = (HWND) lparam;


		if ( h == H_INPUT_SX->hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open( hwnd, H_INPUT_SX->hwnd );
			}

		} else

		if ( h == H_INPUT_SY->hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open( hwnd, H_INPUT_SY->hwnd );
			}

		} else

		if ( h == n_win_combo_hwnd( H_CMB_RESIZE ) )
		{
//n_win_hwndprintf_literal( hwnd, " %d ", wparam );
//break;
			if ( ( wparam >= WM_MOUSEFIRST )&&( wparam <= WM_MOUSELAST ) ) { break; }


			EnableWindow( H_LBL_SIZE      , true );
			EnableWindow( H_INPUT_SX->hwnd, true );
			EnableWindow( H_INPUT_SY->hwnd, true );

			EnableWindow( H_LBL_COLOR, true );
			EnableWindow( n_win_combo_hwnd( H_CMB_COLOR ), true );
			nwscr_enable( H_SCR_ROUND, true );
			nwscr_enable( H_SCR_GAMMA, true );
			nwscr_enable( H_SCR_CLRWH, true );
			nwscr_enable( H_SCR_VIVID, true );
			nwscr_enable( H_SCR_SHARP, true );
			nwscr_enable( H_SCR_CTRST, true );


			n_posix_char *str = n_win_combo_selection_get( H_CMB_RESIZE );

			n_win_txtbox_grayed( H_INPUT_SX, false );
			n_win_txtbox_grayed( H_INPUT_SY, false );

			if ( n_string_is_same_literal( MSG_RESIZE_FIT_X,    str ) )
			{
				EnableWindow( H_INPUT_SY->hwnd, false );
				n_win_txtbox_grayed( H_INPUT_SY,  true );
			} else
			if ( n_string_is_same_literal( MSG_RESIZE_FIT_Y,    str ) )
			{
				EnableWindow( H_INPUT_SX->hwnd, false );
				n_win_txtbox_grayed( H_INPUT_SX,  true );
			} else
			if (
				( n_string_is_same_literal( MSG_RESIZE_SYMMETRY_L_TO_R, str ) )
				||
				( n_string_is_same_literal( MSG_RESIZE_SYMMETRY_R_TO_L, str ) )
			)
			{
				EnableWindow( H_LBL_SIZE,  false );

				EnableWindow( H_INPUT_SX->hwnd, false );
				EnableWindow( H_INPUT_SY->hwnd, false );
				n_win_txtbox_grayed( H_INPUT_SX,  true );
				n_win_txtbox_grayed( H_INPUT_SY,  true );

				EnableWindow( H_LBL_COLOR, false );
				EnableWindow( n_win_combo_hwnd( H_CMB_COLOR ), false );
				nwscr_enable( H_SCR_ROUND, false );
				nwscr_enable( H_SCR_GAMMA, false );
				nwscr_enable( H_SCR_CLRWH, false );
				nwscr_enable( H_SCR_VIVID, false );
				nwscr_enable( H_SCR_SHARP, false );
				nwscr_enable( H_SCR_CTRST, false );
			}

		} else

		if ( h == H_BUTTON )
		{

			n_paint_resizer_go();

			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_ROUND ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_round == wparam )
			)
			{
				break;
			}

			n_paint_resizer_round = wparam;


#ifdef UNICODE
			const n_posix_char *str_degree = L"\x00b0";
#else // #define UNICODE
			const n_posix_char *str_degree = "";
#endif // #define UNICODE

			n_win_hwndprintf_literal( H_SCR_ROUND->value, "%d%s", n_paint_resizer_round - 360, str_degree );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_GAMMA ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_gamma == wparam )
			)
			{
				break;
			}

			n_paint_resizer_gamma = wparam;

			n_win_hwndprintf_literal( H_SCR_GAMMA->value, "%1.1f", (double) n_paint_resizer_gamma / 10.0 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_CLRWH ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_clrwh == wparam )
			)
			{
				break;
			}

			n_paint_resizer_clrwh = wparam;

			n_win_hwndprintf_literal( H_SCR_CLRWH->value, "%d", n_paint_resizer_clrwh - 128 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_VIVID ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_vivid == wparam )
			)
			{
				break;
			}

			n_paint_resizer_vivid = wparam;

			n_win_hwndprintf_literal( H_SCR_VIVID->value, "%d", n_paint_resizer_vivid - 100 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_SHARP ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_sharp == wparam )
			)
			{
				break;
			}

			n_paint_resizer_sharp = wparam;

			n_win_hwndprintf_literal( H_SCR_SHARP->value, "%d", n_paint_resizer_sharp - 100 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_CTRST ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_ctrst == wparam )
			)
			{
				break;
			}

			n_paint_resizer_ctrst = wparam;

			n_win_hwndprintf_literal( H_SCR_CTRST->value, "%d", n_paint_resizer_ctrst );

		}// else

	}
	break;


	case WM_CLOSE :

		EnableWindow( hwnd_tool, true );
		EnableWindow( hwnd_main, true );


		n_win_inputpopup_autoclose();

		n_win_property_exit_literal( H_INPUT_SX->hwnd, "Number" );
		n_win_property_exit_literal( H_INPUT_SY->hwnd, "Number" );


		n_win_stdfont_exit( n_paint_resizer_hgui, GUI_MAX );

		n_win_combo_exit( H_CMB_RESIZE );
		n_win_combo_exit( H_CMB_COLOR  );

		n_win_scroller_exit( H_SCR_ROUND );
		n_win_scroller_exit( H_SCR_GAMMA );
		n_win_scroller_exit( H_SCR_CLRWH );
		n_win_scroller_exit( H_SCR_VIVID );
		n_win_scroller_exit( H_SCR_SHARP );
		n_win_scroller_exit( H_SCR_CTRST );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	case WM_TIMER :

		if ( wparam == target_timer )
		{
			n_win_timer_exit( hwnd, target_timer );

			target_input = NULL;
			target_combo = NULL;

			H_SCR_ROUND->scrollbar.stop_onoff = false;
			H_SCR_GAMMA->scrollbar.stop_onoff = false;
			H_SCR_CLRWH->scrollbar.stop_onoff = false;
			H_SCR_VIVID->scrollbar.stop_onoff = false;
			H_SCR_SHARP->scrollbar.stop_onoff = false;
			H_SCR_CTRST->scrollbar.stop_onoff = false;
		}

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}


	n_win_separator_proc( hwnd, msg, wparam, lparam, H_LINE, PS_DOT );


	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BUTTON );


	n_win_inputpopup_proc_light( hwnd, msg, wparam, lparam, H_INPUT_SX->hwnd );
	n_win_inputpopup_proc_light( hwnd, msg, wparam, lparam, H_INPUT_SY->hwnd );

	n_win_inputpopup_patch( hwnd, msg, &wparam, &lparam );

	if ( target_input == NULL )
	{
		if ( n_win_inputpopup_target != NULL )
		{
			target_input = n_win_inputpopup_target;

			H_SCR_ROUND->scrollbar.stop_onoff = true;
			H_SCR_GAMMA->scrollbar.stop_onoff = true;
			H_SCR_CLRWH->scrollbar.stop_onoff = true;
			H_SCR_VIVID->scrollbar.stop_onoff = true;
			H_SCR_SHARP->scrollbar.stop_onoff = true;
			H_SCR_CTRST->scrollbar.stop_onoff = true;
		}
	} else {
		if ( n_win_inputpopup_target == NULL )
		{
			if ( target_timer == 0 ) { target_timer = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, target_timer, 200 );
		}
	}


	n_win_combo_proc( hwnd, msg, &wparam, &lparam, H_CMB_RESIZE );
	n_win_combo_proc( hwnd, msg, &wparam, &lparam, H_CMB_COLOR  );

	if ( target_combo == NULL )
	{
		if ( n_win_combo_target != NULL )
		{
			target_combo = n_win_combo_target;

			H_SCR_ROUND->scrollbar.stop_onoff = true;
			H_SCR_GAMMA->scrollbar.stop_onoff = true;
			H_SCR_CLRWH->scrollbar.stop_onoff = true;
			H_SCR_VIVID->scrollbar.stop_onoff = true;
			H_SCR_SHARP->scrollbar.stop_onoff = true;
			H_SCR_CTRST->scrollbar.stop_onoff = true;
		}
	} else {
		if ( n_win_combo_target == NULL )
		{
			if ( target_timer == 0 ) { target_timer = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, target_timer, 200 );
		}
	}

	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_ROUND );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_GAMMA );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_CLRWH );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_VIVID );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_SHARP );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_CTRST );

	{
		int ret = 0;
		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, H_INPUT_SX );
		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, H_INPUT_SY );
		if ( ret ) { return ret; }
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef H_LBL_RESIZE
#undef H_LBL_SIZE
#undef H_LINE
#undef H_LBL_COLOR
#undef H_BUTTON
#undef GUI_MAX

#undef H_INPUT_SX
#undef H_INPUT_SY
#undef TXT_MAX

#undef H_CMB_RESIZE
#undef H_CMB_COLOR
#undef CMB_MAX

#undef H_SCR_ROUND
#undef H_SCR_GAMMA
#undef H_SCR_CLRWH
#undef H_SCR_VIVID
#undef H_SCR_SHARP
#undef H_SCR_CTRST
#undef SCR_MAX


#undef MSG_SIZE
#undef MSG_RESIZE
#undef MSG_RESIZE_TOPLEFT
#undef MSG_RESIZE_TILE
#undef MSG_RESIZE_CENTER
#undef MSG_RESIZE_TRANSFORM
#undef MSG_RESIZE_FIT_X
#undef MSG_RESIZE_FIT_Y
#undef MSG_RESIZE_SYMMETRY_L_TO_R
#undef MSG_RESIZE_SYMMETRY_R_TO_L
#undef MSG_ROUND
#undef MSG_COLOR
#undef MSG_COLOR_NONE
#undef MSG_COLOR_GRAY
#undef MSG_COLOR_MONO
#undef MSG_COLOR_MASK
#undef MSG_COLOR_SIZE
#undef MSG_GAMMA
#undef MSG_CLRWH
#undef MSG_VIVID
#undef MSG_SHARP
#undef MSG_CTRST

