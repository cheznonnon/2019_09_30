// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/bmp.c"
#include "../nonnon/neutral/bmp/all.c"




void
n_draw_frame( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, u32 fg, u32 bg )
{

	if ( n_bmp_error( bmp ) ) { return; }


	s32 fx  = x;
	s32 fy  = y;
	s32 tx  = x + sx - 1;
	s32 ty  = y + sy - 1;


	// Top
	n_bmp_line_dot( bmp, fx,fy,tx,fy, fg, 1 );
	n_bmp_line_dot( bmp, fx,fy,tx,fy, bg, 2 );

	// Bottom
	n_bmp_line_dot( bmp, fx,ty,tx,ty, fg, 1 );
	n_bmp_line_dot( bmp, fx,ty,tx,ty, bg, 2 );


	fy++;
	ty--;

	// Left
	n_bmp_line_dot( bmp, fx,fy,fx,ty, fg, 1 );
	n_bmp_line_dot( bmp, fx,fy,fx,ty, bg, 2 );

	// Right
	n_bmp_line_dot( bmp, tx,fy,tx,ty, fg, 1 );
	n_bmp_line_dot( bmp, tx,fy,tx,ty, bg, 2 );


	return;
}

void
n_draw_gdi_box( HDC hdc, s32 fx, s32 fy, s32 tx, s32 ty, HGDIOBJ hb )
{

	RECT r = { fx,fy,tx,ty };


	FillRect( hdc, &r, hb );
	ExcludeClipRect( hdc, fx,fy,tx,ty );


	return;
}

void
n_draw_gdi_frame2canvas( HDC hdc, s32 x, s32 y, s32 sx, s32 sy, RECT r, COLORREF fg, COLORREF bg )
{

	s32 size = 2;

	s32 fx,tx,fy,ty;


	HGDIOBJ hb_fg = CreateSolidBrush( fg );
	HGDIOBJ hb_bg = CreateSolidBrush( bg );


	// [!] : Top / Bottom

	fx = x - size;
	tx = x + sx;
	fy = y - size;
	ty = y + sy;

	while( 1 )
	{

		POINT pt_u = { fx, fy };
		POINT pt_d = { fx, ty };

		if ( PtInRect( &r, pt_u ) )
		{
			n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_fg );
		}
		if ( PtInRect( &r, pt_d ) )
		{
			n_draw_gdi_box( hdc, fx, ty, fx + size, ty + size, hb_fg );
		}

		fx += size;

		if ( PtInRect( &r, pt_u ) )
		{
			n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_bg );
		}
		if ( PtInRect( &r, pt_d ) )
		{
			n_draw_gdi_box( hdc, fx, ty, fx + size, ty + size, hb_bg );
		}

		fx += size;

		if ( fx >= tx ) { break; }
	}


	// [!] : Left / Right

	fx = x - size;
	tx = x + sx;
	fy = y - size;
	ty = y + sy;

	while( 1 )
	{//break;

		POINT pt_l = { fx, fy };
		POINT pt_r = { tx, fy };

		if ( PtInRect( &r, pt_l ) ) { n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_fg ); }
		if ( PtInRect( &r, pt_r ) ) { n_draw_gdi_box( hdc, tx, fy, tx + size, fy + size, hb_fg ); }

		fy += size;

		if ( PtInRect( &r, pt_l ) ) { n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_bg ); }
		if ( PtInRect( &r, pt_r ) ) { n_draw_gdi_box( hdc, tx, fy, tx + size, fy + size, hb_bg ); }

		fy += size;

		if ( fy >= ty ) { break; }
	}


	DeleteObject( hb_fg );
	DeleteObject( hb_bg );


	return;
}

void
n_draw_gdi_clear( HDC hdc, HWND hwnd, COLORREF color )
{

	// [!] : Classic Theme : alpha value causes black-out

	color &= 0x00ffffff;


	HBRUSH hb = CreateSolidBrush( color );
	RECT   r;   GetClientRect( hwnd, &r );

	FillRect( hdc, &r, hb );

	DeleteObject( hb );


	return;
}

void
n_draw_gdi_clear_simple( HWND hwnd, COLORREF color )
{

	HDC hdc = GetDC( hwnd );

	n_draw_gdi_clear( hdc, hwnd, color );

	ReleaseDC( hwnd, hdc );


	return;
}

void
n_draw_gdi_mask( HDC hdc, HWND hgui )
{

	s32 x,y,sx,sy;
	n_win_location( hgui, &x, &y, &sx, &sy );

	ExcludeClipRect( hdc, x, y, x + sx, y + sy );


	return;
}

